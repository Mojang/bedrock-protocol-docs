export declare function mergeOptionalArrays<T>(parent: T[] | undefined | null, merge: T[] | undefined | null): T[] | undefined;
