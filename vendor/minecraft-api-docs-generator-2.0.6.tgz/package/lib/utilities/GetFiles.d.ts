export declare function readFile(filePath: string): Buffer | undefined;
export declare function getFiles(dir: string): string[];
export declare function getFilesRecursively(dir: string): string[];
