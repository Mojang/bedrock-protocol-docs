export declare function nameSortComparer(element1: Record<'name', string>, element2: Record<'name', string>): number;
export declare function semVerSortComparer<SemVerKey extends 'version' | 'minecraft_version' | 'schema_version'>(semverKeyName: SemVerKey): (element1: Record<SemVerKey, string>, element2: Record<SemVerKey, string>) => number;
export declare function reverseSemVerSortComparer<SemVerKey extends 'version' | 'minecraft_version' | 'schema_version'>(semverKeyName: SemVerKey): (element1: Record<SemVerKey, string>, element2: Record<SemVerKey, string>) => number;
