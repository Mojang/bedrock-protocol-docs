export declare function removePropertyRecursive(value: Record<string, unknown>, propertyName: string): void;
