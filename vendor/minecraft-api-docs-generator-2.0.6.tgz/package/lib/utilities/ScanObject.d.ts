import { KeyToParentTypeMapping, KeyToTypeMapping } from '../modules/KeyToTypeMapping';
export declare function scanObjectForMemberArray(object: Record<string, unknown>, callback: (parentObject: Record<string, Array<unknown>>, propertyName: string) => void): void;
/**
 * Scan for all objects with a property with the specified name.
 *
 * If KeyType exists as a key of KeyToTypeMapping, the parent object is a Record with a key of the mapped type,
 * If KeyType also exists as a key of KeyToParentTypeMapping, the parent object is the type defined in that mapping
 * Otherwise if the KeyType is not a key of either mapping, the parent object is a dictionary with unknown keys
 */
export declare function scanObjectForMemberWithName<KeyType extends string, ParentType = KeyType extends keyof KeyToTypeMapping ? KeyType extends keyof KeyToParentTypeMapping ? KeyToParentTypeMapping[KeyType] : Record<KeyType, KeyToTypeMapping[KeyType]> : Record<string, unknown>>(object: Record<string, unknown>, memberName: KeyType, callback: (parentObject: ParentType) => void): void;
export declare function scanObjectForMembersWithNamesNoChangelog<KeyType1 extends keyof KeyToTypeMapping, KeyType2 extends keyof KeyToTypeMapping, ParentType = Pick<KeyToTypeMapping, KeyType1 | KeyType2>>(object: Record<string, unknown>, memberName1: KeyType1, memberName2: KeyType2, callback: (parentObject: ParentType) => void): void;
export declare function scanObjectForMembersWithNames<KeyType1 extends keyof KeyToTypeMapping, KeyType2 extends keyof KeyToTypeMapping, ParentType = Pick<KeyToTypeMapping, KeyType1 | KeyType2>>(object: Record<string, unknown>, memberName1: KeyType1, memberName2: KeyType2, callback: (parentObject: ParentType) => void): void;
export declare function scanObjectForMemberWithAnyNamesFromList(object: Record<string, unknown>, memberNames: string[], callback: (parentObject: Record<string, unknown>, propertyName: string) => void): void;
