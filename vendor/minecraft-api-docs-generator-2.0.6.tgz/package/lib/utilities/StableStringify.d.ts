/**
 * Serialize a value to JSON with object keys emitted in sorted order at every
 * level of the structure. This makes the result suitable for order-insensitive
 * equality comparisons (two objects with the same keys/values in different
 * insertion orders produce identical strings).
 *
 * Optionally, a list of submember keys to ignore can be supplied; any property
 * whose key matches will be omitted from the output (at any depth).
 */
export declare function stableStringify(value: unknown, ignoredSubmembers?: readonly string[]): string | undefined;
