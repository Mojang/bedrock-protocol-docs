export type GenericObject = Record<string, unknown>;
export declare function longestCommonSubsequence(oldArray: GenericObject[], newArray: GenericObject[], key: string): unknown[];
export declare function diffArray(oldArray: GenericObject[] | undefined, newArray: GenericObject[] | undefined, key: string): GenericObject[];
