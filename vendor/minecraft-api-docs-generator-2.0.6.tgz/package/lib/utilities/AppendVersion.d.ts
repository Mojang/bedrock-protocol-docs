import semver from 'semver';
/**
 * Appends unique build info to pre-release tags to ensure unique module names per release.
 *
 * If 'onlyUsePrereleaseInfo' is set to true, we only use the prerelease part of the Minecraft version,
 * e.g. "-preview.5" out of "1.2.3-preview.5"
 */
export declare function appendMinecraftVersion(parsedVersion: semver.SemVer, minecraftVersion: semver.SemVer, onlyUsePrereleaseInfo?: boolean): string;
