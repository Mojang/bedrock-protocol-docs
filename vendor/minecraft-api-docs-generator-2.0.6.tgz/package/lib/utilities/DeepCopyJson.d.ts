export type DeepCopyType<T> = T extends object ? {
    [K in keyof T]: DeepCopyType<T[K]>;
} : T;
export declare function deepCopyJson<T>(value: T): DeepCopyType<T>;
