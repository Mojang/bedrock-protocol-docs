import { MinecraftRelease } from './MinecraftRelease';
import { IMinecraftModule } from './modules/IMinecraftModule';
export type ChangelogVersionKey = 'version' | 'minecraft_version';
export interface ChangelogStrategy {
    getVersionKey(): ChangelogVersionKey;
    generateModuleGroupKey(module: IMinecraftModule): string;
    generateModuleGroups(releases: MinecraftRelease[]): IMinecraftModule[][];
    shouldGenerateChangelogs(releases: MinecraftRelease[]): boolean;
}
/**
 * Perform no diffing between modules, will not populate 'changelog' fields.
 */
export declare class DisabledChangelogStrategy implements ChangelogStrategy {
    getVersionKey(): 'version';
    generateModuleGroupKey(): string;
    generateModuleGroups(): IMinecraftModule[][];
    shouldGenerateChangelogs(): boolean;
}
/**
 * Buckets modules per module version to compare same module across multiple versions of its self regardless of Minecraft version.
 *
 * Only applies to Script modules, other module types are only versioned based on Minecraft version.
 */
export declare class ModuleVersionChangelogStrategy implements ChangelogStrategy {
    getVersionKey(): 'version';
    generateModuleGroupKey(module: IMinecraftModule): string;
    generateModuleGroups(releases: MinecraftRelease[]): IMinecraftModule[][];
    shouldGenerateChangelogs(releases: MinecraftRelease[]): boolean;
}
/**
 * Buckets modules per Minecraft version to compare same module versions across multiple Minecraft releases.
 */
export declare class MinecraftVersionChangelogStrategy implements ChangelogStrategy {
    getVersionKey(): 'minecraft_version';
    generateModuleGroupKey(module: IMinecraftModule): string;
    generateModuleGroups(releases: MinecraftRelease[]): IMinecraftModule[][];
    shouldGenerateChangelogs(releases: MinecraftRelease[]): boolean;
}
export declare const CoreChangelogStrategies: [string, ChangelogStrategy][];
