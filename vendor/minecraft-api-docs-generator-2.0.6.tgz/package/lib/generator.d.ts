import { GenerateOptions } from './Config';
import { MinecraftScriptModule } from './modules/MinecraftScriptModule';
/**
 * Merges each script module that specifies a 'parentModule' with it's parent, returning the list of all modules after merging.
 *
 * If 'includeBaseModules' is true, base modules will be generated on their own in addition to the merged modules.
 */
export declare function getMergedScriptModules(includeBaseModules: boolean, scriptModules: MinecraftScriptModule[]): MinecraftScriptModule[];
/**
 * Main logic of the Minecraft API Docs Generator.
 *
 * Processes API module JSON metadata files, transforming them with filter functions,
 * and renders them into output files with configured markup generators.
 */
export declare function generate(options: GenerateOptions): Promise<void>;
