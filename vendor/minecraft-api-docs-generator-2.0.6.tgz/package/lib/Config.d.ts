import { CosmiconfigResult } from 'cosmiconfig';
import * as rt from 'runtypes';
export declare const CONFIG_NAME = "api-docs-generator";
/**
 * Helper for finding the config file using cosmiconfig.
 */
export declare function findConfig(): Promise<CosmiconfigResult>;
/**
 * Helper for type validating config file.
 */
export declare function checkConfig(config: Config): Config;
export declare const PreexistingModuleReleasesRecord: rt.Dictionary<rt.Array<rt.String, false>, string>;
export type PreexistingModuleReleases = rt.Static<typeof PreexistingModuleReleasesRecord>;
export declare const IncludeModulesModeUnion: rt.Union<[rt.Literal<"all">, rt.Literal<"latest">]>;
export type IncludeModulesMode = rt.Static<typeof IncludeModulesModeUnion>;
declare const PluginOptionsRecord: rt.Intersect<[rt.Record<{
    path: rt.Optional<rt.String>;
}, false>, rt.Dictionary<rt.Unknown, string>]>;
export type PluginOptions = rt.Static<typeof PluginOptionsRecord>;
declare const PluginConfigRecord: rt.Union<[rt.String, rt.Tuple<[rt.String, rt.Intersect<[rt.Record<{
    path: rt.Optional<rt.String>;
}, false>, rt.Dictionary<rt.Unknown, string>]>]>, rt.Constraint<rt.Array<rt.String, false>, string[], unknown>]>;
/**
 * The plugin config is a tuple of plugin module names and objects containing plugin-specific options.
 *
 * Plugins will be imported from node_modules by name or from a path if specified.
 *
 * Example:
 * ```
 * [
 *   'plugin-module',
 *   ['plugin-with-options', { path: './path/to/plugin.js' }]
 * ]
 * ```
 */
export type PluginConfig = rt.Static<typeof PluginConfigRecord>;
declare const ConfigOptionsRecord: rt.Record<{
    inputDirectory: rt.Optional<rt.String>;
    outputDirectory: rt.Optional<rt.String>;
    documentationDirectory: rt.Optional<rt.String>;
    generatorsToRun: rt.Optional<rt.Array<rt.String, false>>;
    changelogStrategy: rt.Optional<rt.String>;
    minecraftReleaseVersion: rt.Optional<rt.String>;
    preexistingModuleReleases: rt.Optional<rt.Dictionary<rt.Array<rt.String, false>, string>>;
    includeModulesMode: rt.Optional<rt.Union<[rt.Literal<"all">, rt.Literal<"latest">]>>;
    includeBaseModules: rt.Optional<rt.Boolean>;
    skipMerging: rt.Optional<rt.Boolean>;
    plugins: rt.Optional<rt.Array<rt.Union<[rt.String, rt.Tuple<[rt.String, rt.Intersect<[rt.Record<{
        path: rt.Optional<rt.String>;
    }, false>, rt.Dictionary<rt.Unknown, string>]>]>, rt.Constraint<rt.Array<rt.String, false>, string[], unknown>]>, false>>;
    generators: rt.Optional<rt.Dictionary<rt.Dictionary<rt.Unknown, string>, string>>;
    log: rt.Optional<rt.Record<{
        level: rt.Optional<rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>>;
        allMessages: rt.Optional<rt.Union<[rt.Boolean, rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>]>>;
        undocumentedApis: rt.Optional<rt.Union<[rt.Boolean, rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>]>>;
        unusedDocumentation: rt.Optional<rt.Union<[rt.Boolean, rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>]>>;
        unresolvedDependencies: rt.Optional<rt.Union<[rt.Boolean, rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>]>>;
        unresolvedTypes: rt.Optional<rt.Union<[rt.Boolean, rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>]>>;
    }, false>>;
}, false>;
/**
 * Options used by generate() that can be invoked through CLI.
 */
export type GenerateOptions = rt.Static<typeof ConfigOptionsRecord> & {
    configPath?: string;
    ignoreConfig?: boolean;
};
/**
 * 'api-generator.config.mjs' config schema.
 */
export type Config = rt.Static<typeof ConfigOptionsRecord>;
/**
 * Options from config files and generate() arguments.
 */
export type ConfigOptions = GenerateOptions & Config;
export {};
