import { Array, Boolean, Intersect, Literal, Optional, Record, Runtype, Static, String, Union } from 'runtypes';
/**
 * The supported module types for documentation generation.
 */
export declare const ModuleTypesValidator: Union<[Literal<"script">, Literal<"commands">, Literal<"after_events_ordering">, Literal<"vanilla_data">, Literal<"molang">]>;
export type ModuleTypes = Static<typeof ModuleTypesValidator>;
/**
 * Most common piece of data for generation, a name field.
 */
export declare const ModuleNameDataValidator: Record<{
    name: String;
}, false>;
export type ModuleNameData = Static<typeof ModuleNameDataValidator>;
/**
 * Common module data for all types of modules
 */
export declare const CommonModuleDataValidator: Record<{
    name: String;
    minecraft_version: String;
    module_type: Union<[Literal<"script">, Literal<"commands">, Literal<"after_events_ordering">, Literal<"vanilla_data">, Literal<"molang">]>;
    module_name: Optional<String>;
}, false>;
export type IMinecraftModule = Static<typeof CommonModuleDataValidator>;
/**
 * Common data for runtime comment flags
 */
export declare const CommonCommentFlagsValidator: Record<{
    has_comments: Optional<Boolean>;
}, false>;
/**
 * Standardized Vanilla Name Record and optional states
 */
export declare const StandardizedVanillaNameRecord: Record<{
    namespace: Optional<String>;
    no_namespace_name: Optional<String>;
    standardized_name: Optional<String>;
}, false>;
/**
 * Additional data that may be associated with data_items
 */
export declare const DataStateRecord: Record<{
    properties: Optional<Array<Record<{
        name: String;
    }, false>, false>>;
    state_union: Optional<String>;
    value: Optional<String>;
}, false>;
/**
 * Runtime specific fields for module name data in vanilla data modules
 */
export declare const VanillaModuleNameDataValidator: Intersect<[Intersect<[Record<{
    name: String;
}, false>, Record<{
    namespace: Optional<String>;
    no_namespace_name: Optional<String>;
    standardized_name: Optional<String>;
}, false>]>, Record<{
    properties: Optional<Array<Record<{
        name: String;
    }, false>, false>>;
    state_union: Optional<String>;
    value: Optional<String>;
}, false>]>;
export type VanillaModuleNameData = Static<typeof VanillaModuleNameDataValidator>;
export declare const CoreVanillaDataFieldsRecord: Intersect<[Record<{
    data_items: Array<Intersect<[Intersect<[Record<{
        name: String;
    }, false>, Record<{
        namespace: Optional<String>;
        no_namespace_name: Optional<String>;
        standardized_name: Optional<String>;
    }, false>]>, Record<{
        properties: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        state_union: Optional<String>;
        value: Optional<String>;
    }, false>]>, false>;
    vanilla_data_type: Optional<String>;
    module_type: Literal<"vanilla_data">;
    display_type: Optional<String>;
    display_name: Optional<String>;
    has_properties: Optional<Boolean>;
}, false>, Record<{
    name: String;
    minecraft_version: String;
    module_type: Union<[Literal<"script">, Literal<"commands">, Literal<"after_events_ordering">, Literal<"vanilla_data">, Literal<"molang">]>;
    module_name: Optional<String>;
}, false>]>;
export type CoreVanillaDataFields = Static<typeof CoreVanillaDataFieldsRecord>;
/**
 * Common vanilla data fields for all types of modules
 */
export declare function getCommonVanillaDataFieldsRecord<T extends Runtype>(base: T, literalType: string): Intersect<[Intersect<[Record<{
    data_items: Array<Intersect<[Intersect<[Record<{
        name: String;
    }, false>, Record<{
        namespace: Optional<String>;
        no_namespace_name: Optional<String>;
        standardized_name: Optional<String>;
    }, false>]>, Record<{
        properties: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        state_union: Optional<String>;
        value: Optional<String>;
    }, false>]>, false>;
    vanilla_data_type: Optional<String>;
    module_type: Literal<"vanilla_data">;
    display_type: Optional<String>;
    display_name: Optional<String>;
    has_properties: Optional<Boolean>;
}, false>, Record<{
    name: String;
    minecraft_version: String;
    module_type: Union<[Literal<"script">, Literal<"commands">, Literal<"after_events_ordering">, Literal<"vanilla_data">, Literal<"molang">]>;
    module_name: Optional<String>;
}, false>]>, Record<{
    data_items: Array<T, false>;
    vanilla_data_type: Optional<Literal<string>>;
}, false>]>;
export type CommonVanillaDataFields = Static<ReturnType<typeof getCommonVanillaDataFieldsRecord>>;
export type RuntimeDataModule<T> = T extends IMinecraftModule ? T : never;
