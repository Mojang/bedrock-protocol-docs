import { CoreVanillaDataFields, IMinecraftModule } from './IMinecraftModule';
import { MinecraftBlockModule } from './MinecraftBlockModule';
export type MinecraftVanillaDataModule = CoreVanillaDataFields | MinecraftBlockModule;
export declare function isVanillaDataModule(module: IMinecraftModule): module is MinecraftVanillaDataModule;
