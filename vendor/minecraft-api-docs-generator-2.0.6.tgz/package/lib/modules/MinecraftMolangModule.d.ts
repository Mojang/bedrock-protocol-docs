import { Array, Intersect, Literal, Number, Optional, Record, Static, String } from 'runtypes';
/**
 * A version range for a Molang query which includes change description and pertinent query sets
 */
export declare const MinecraftMolangVersionRangeRecord: Record<{
    first_version: String;
    last_version: Optional<String>;
    query_sets: Optional<Array<String, false>>;
    version_change_description: Optional<String>;
}, false>;
/**
 * A Molang query function
 */
export declare const MinecraftMolangQueryRecord: Record<{
    name: String;
    description: Optional<String>;
    return_type: String;
    min_args: Number;
    max_args: Optional<Number>;
    experiments: Optional<Array<String, false>>;
    version_ranges: Array<Record<{
        first_version: String;
        last_version: Optional<String>;
        query_sets: Optional<Array<String, false>>;
        version_change_description: Optional<String>;
    }, false>, false>;
}, false>;
export type MinecraftMolangQuery = Static<typeof MinecraftMolangQueryRecord>;
/**
 * A built in molang math function
 */
export declare const MinecraftMolangMathRecord: Record<{
    name: String;
    description: Optional<String>;
    min_args: Number;
    max_args: Optional<Number>;
}, false>;
export type MinecraftMolangMath = Static<typeof MinecraftMolangMathRecord>;
/**
 * Molang module containing queries, variables, and math functions
 */
export declare const MinecraftMolangModuleRecord: Intersect<[Record<{
    name: String;
    minecraft_version: String;
    module_type: import("runtypes").Union<[Literal<"script">, Literal<"commands">, Literal<"after_events_ordering">, Literal<"vanilla_data">, Literal<"molang">]>;
    module_name: Optional<String>;
}, false>, Record<{
    module_type: Literal<"molang">;
    queries: Optional<Array<Record<{
        name: String;
        description: Optional<String>;
        return_type: String;
        min_args: Number;
        max_args: Optional<Number>;
        experiments: Optional<Array<String, false>>;
        version_ranges: Array<Record<{
            first_version: String;
            last_version: Optional<String>;
            query_sets: Optional<Array<String, false>>;
            version_change_description: Optional<String>;
        }, false>, false>;
    }, false>, false>>;
    math_functions: Optional<Array<Record<{
        name: String;
        description: Optional<String>;
        min_args: Number;
        max_args: Optional<Number>;
    }, false>, false>>;
}, false>]>;
export type MinecraftMolangModule = Static<typeof MinecraftMolangModuleRecord>;
