import { Intersect, Literal, Record, Static } from 'runtypes';
export declare const MinecraftEntitiesModuleRecord: Intersect<[Intersect<[Intersect<[Record<{
    data_items: import("runtypes").Array<Intersect<[Intersect<[Record<{
        name: import("runtypes").String;
    }, false>, Record<{
        namespace: import("runtypes").Optional<import("runtypes").String>;
        no_namespace_name: import("runtypes").Optional<import("runtypes").String>;
        standardized_name: import("runtypes").Optional<import("runtypes").String>;
    }, false>]>, Record<{
        properties: import("runtypes").Optional<import("runtypes").Array<Record<{
            name: import("runtypes").String;
        }, false>, false>>;
        state_union: import("runtypes").Optional<import("runtypes").String>;
        value: import("runtypes").Optional<import("runtypes").String>;
    }, false>]>, false>;
    vanilla_data_type: import("runtypes").Optional<import("runtypes").String>;
    module_type: Literal<"vanilla_data">;
    display_type: import("runtypes").Optional<import("runtypes").String>;
    display_name: import("runtypes").Optional<import("runtypes").String>;
    has_properties: import("runtypes").Optional<import("runtypes").Boolean>;
}, false>, Record<{
    name: import("runtypes").String;
    minecraft_version: import("runtypes").String;
    module_type: import("runtypes").Union<[Literal<"script">, Literal<"commands">, Literal<"after_events_ordering">, Literal<"vanilla_data">, Literal<"molang">]>;
    module_name: import("runtypes").Optional<import("runtypes").String>;
}, false>]>, Record<{
    data_items: import("runtypes").Array<Intersect<[Intersect<[Record<{
        name: import("runtypes").String;
    }, false>, Record<{
        namespace: import("runtypes").Optional<import("runtypes").String>;
        no_namespace_name: import("runtypes").Optional<import("runtypes").String>;
        standardized_name: import("runtypes").Optional<import("runtypes").String>;
    }, false>]>, Record<{
        properties: import("runtypes").Optional<import("runtypes").Array<Record<{
            name: import("runtypes").String;
        }, false>, false>>;
        state_union: import("runtypes").Optional<import("runtypes").String>;
        value: import("runtypes").Optional<import("runtypes").String>;
    }, false>]>, false>;
    vanilla_data_type: import("runtypes").Optional<Literal<string>>;
}, false>]>, Record<{
    module_type: Literal<"vanilla_data">;
}, false>]>;
export type MinecraftEntitiesModule = Static<typeof MinecraftEntitiesModuleRecord>;
