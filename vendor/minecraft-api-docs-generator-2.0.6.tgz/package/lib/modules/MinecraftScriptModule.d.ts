import { Array, Boolean, Intersect, Literal, Number, Optional, Record, Runtype, Static, String, Union, Unknown } from 'runtypes';
import { IMinecraftModule } from './IMinecraftModule';
/**
 * Common type for named objects which get additional formatted names added at runtime
 */
export declare const NameMarkupRecord: Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>;
export type NameMarkupType = Static<typeof NameMarkupRecord>;
/**
 * Common type for objects with versions for additional formatted version info added at runtime
 */
export declare const VersionMarkupRecord: Record<{
    version: String;
    version_bookmark_name: Optional<String>;
    version_selector: Optional<String>;
}, false>;
export type VersionMarkupType = Static<typeof VersionMarkupRecord>;
/**
 * Common type for runtime markup of documentation formatting tags
 */
export declare const MarkupCommentFlagsValidator: Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>;
export type MarkupCommentFlags = Static<typeof MarkupCommentFlagsValidator>;
/**
 * Flags to determine whether the generated markup came from native metadata or directly
 * from script. Based on this flag, script specific markup could be used instead.
 */
export declare const MarkupSourceValidator: Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>;
export type MarkupSource = Static<typeof MarkupSourceValidator>;
export declare const MinecraftExampleRecord: Intersect<[Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    code: Record<{
        text: Array<String, false>;
        escaped_text: Array<String, false>;
    }, false>;
}, false>]>;
export type MinecraftExample = Static<typeof MinecraftExampleRecord>;
/**
 * Common type for markup added during generation
 */
export declare const DocumentationMarkupValidator: Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>;
export type MinecraftDocumentableObject = Static<typeof DocumentationMarkupValidator>;
export declare const PrivilegeValueTypeRecord: Record<{
    name: String;
}, false>;
export type PrivilegeValueType = Static<typeof PrivilegeValueTypeRecord>;
export declare enum PrivilegeTypes {
    Default = "default",
    RestrictedExec = "restricted_execution",
    EarlyExec = "early_execution",
    Deprecated_None = "none",// now default
    Deprecated_ReadOnly = "read_only"
}
export declare const MinecraftModuleDescriptionRecord: Intersect<[Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    version: String;
    version_bookmark_name: Optional<String>;
    version_selector: Optional<String>;
}, false>, Record<{
    uuid: Optional<String>;
    is_external_module: Optional<Boolean>;
    prior_version: Optional<String>;
    folder_path: Optional<String>;
}, false>]>;
export type MinecraftModuleDescription = Static<typeof MinecraftModuleDescriptionRecord>;
export declare const MinecraftModuleDependencyRecord: Intersect<[Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    uuid: Optional<String>;
    versions: Array<Record<{
        version: String;
        version_bookmark_name: Optional<String>;
        version_selector: Optional<String>;
    }, false>, false>;
    types_only: Optional<Boolean>;
    from_module: Optional<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        version: String;
        version_bookmark_name: Optional<String>;
        version_selector: Optional<String>;
    }, false>, Record<{
        uuid: Optional<String>;
        is_external_module: Optional<Boolean>;
        prior_version: Optional<String>;
        folder_path: Optional<String>;
    }, false>]>>;
    is_latest_major: Optional<Boolean>;
    is_vanilla_data: Optional<Boolean>;
}, false>]>;
export type MinecraftModuleDependency = Static<typeof MinecraftModuleDependencyRecord>;
export declare const MinecraftTypeKeyList: string[];
export declare const MinecraftClosureTypeRecord: Record<{
    argument_types: Array<Runtype<MinecraftTypeHelper>, false>;
    return_type: Runtype<MinecraftTypeHelper>;
    call_privilege: Optional<Record<{
        name: String;
    }, false>>;
}, false>;
export type MinecraftClosureType = Static<typeof MinecraftClosureTypeRecord>;
export declare const MinecraftGeneratorTypeRecord: Record<{
    yield_type: Runtype<MinecraftTypeHelper>;
    return_type: Runtype<MinecraftTypeHelper>;
    next_type: Runtype<MinecraftTypeHelper>;
}, false>;
export type MinecraftGeneratorType = Static<typeof MinecraftGeneratorTypeRecord>;
type MinecraftTypeHelper = {
    name: string;
    is_errorable: boolean;
    is_bind_type: boolean;
    from_module?: MinecraftModuleDescription;
    valid_range?: {
        min: number;
        max: number;
    };
    closure_type?: MinecraftClosureType;
    element_type?: MinecraftTypeHelper;
    error_types?: MinecraftTypeHelper[];
    generator_type?: MinecraftGeneratorType;
    iterator_type?: MinecraftTypeHelper;
    key_type?: MinecraftTypeHelper;
    optional_type?: MinecraftTypeHelper;
    promise_type?: MinecraftTypeHelper;
    value_type?: MinecraftTypeHelper;
    variant_types?: MinecraftTypeHelper[];
    data_buffer_type?: MinecraftTypeHelper;
    original_name?: string;
    is_void_return?: boolean;
    is_string?: boolean;
    is_undefined?: boolean;
    is_any?: boolean;
    is_closure?: boolean;
    is_array?: boolean;
    is_promise?: boolean;
    is_variant?: boolean;
    is_optional?: boolean;
    is_optional_type?: boolean;
    is_iterator?: boolean;
    is_iterator_result?: boolean;
    is_map?: boolean;
    is_generator?: boolean;
    is_data_buffer?: boolean;
};
export declare const MinecraftTypeRecord: Runtype<MinecraftTypeHelper>;
export type MinecraftType = Static<typeof MinecraftTypeRecord>;
export declare const MinecraftObjectRecord: Intersect<[Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
}, false>]>;
export type MinecraftObject = Static<typeof MinecraftObjectRecord>;
export declare function hasObjects(obj: object): obj is {
    objects: MinecraftObject[];
};
export declare const MinecraftConstantRecord: Intersect<[Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    type: Runtype<MinecraftTypeHelper>;
    is_read_only: Literal<true>;
    is_static: Literal<true>;
    value: Optional<Unknown>;
    property_name: Optional<String>;
    property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    is_member: Optional<Literal<true>>;
    constant_value: Optional<Record<{
        value: Unknown;
    }, false>>;
}, false>]>;
export type MinecraftConstant = Static<typeof MinecraftConstantRecord>;
export declare function hasConstants(obj: object): obj is {
    constants: MinecraftConstant[];
};
export declare const MinecraftEnumRecord: Intersect<[Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    constants: Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        is_read_only: Literal<true>;
        is_static: Literal<true>;
        value: Optional<Unknown>;
        property_name: Optional<String>;
        property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Literal<true>>;
        constant_value: Optional<Record<{
            value: Unknown;
        }, false>>;
    }, false>]>, false>;
    from_module: Optional<Union<[Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        version: String;
        version_bookmark_name: Optional<String>;
        version_selector: Optional<String>;
    }, false>, Record<{
        uuid: Optional<String>;
        is_external_module: Optional<Boolean>;
        prior_version: Optional<String>;
        folder_path: Optional<String>;
    }, false>]>, Literal<null>]>>;
    is_enum: Optional<Literal<true>>;
    enum_name: Optional<Union<[String, Literal<null>]>>;
    enum_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    show_prior_warning: Optional<Boolean>;
    prior_link: Optional<String>;
}, false>]>;
export type MinecraftEnum = Static<typeof MinecraftEnumRecord>;
export declare function hasEnums(obj: object): obj is {
    enums: MinecraftEnum[];
};
export declare const MinecraftPropertyRecord: Intersect<[Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    type: Runtype<MinecraftTypeHelper>;
    is_read_only: Boolean;
    min_value: Optional<Union<[Unknown, Literal<null>]>>;
    max_value: Optional<Union<[Unknown, Literal<null>]>>;
    is_baked: Optional<Boolean>;
    default_value: Optional<Union<[Unknown, Literal<null>]>>;
    min_added: Optional<Boolean>;
    min_changed: Optional<Boolean>;
    min_removed: Optional<Boolean>;
    max_added: Optional<Boolean>;
    max_changed: Optional<Boolean>;
    max_removed: Optional<Boolean>;
    max_length: Optional<Union<[Number, Literal<null>]>>;
    max_length_added: Optional<Boolean>;
    max_length_changed: Optional<Boolean>;
    max_length_removed: Optional<Boolean>;
    property_name: Optional<Union<[String, Literal<null>]>>;
    property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    is_member: Optional<Boolean>;
    get_privilege: Optional<Array<Record<{
        name: String;
    }, false>, false>>;
    set_privilege: Optional<Array<Record<{
        name: String;
    }, false>, false>>;
    get_allowed_in_early_execution: Optional<Boolean>;
    set_allowed_in_early_execution: Optional<Boolean>;
    get_disallowed_in_restricted_execution: Optional<Boolean>;
    set_disallowed_in_restricted_execution: Optional<Boolean>;
}, false>]>;
export type MinecraftProperty = Static<typeof MinecraftPropertyRecord>;
export declare function hasProperties(obj: object): obj is {
    properties: MinecraftProperty[];
};
export declare const MinecraftFunctionArgumentDetailsRecord: Record<{
    default_value: Optional<Union<[Unknown, Literal<null>]>>;
    min_value: Optional<Union<[Unknown, Literal<null>]>>;
    max_value: Optional<Union<[Unknown, Literal<null>]>>;
    supported_values: Optional<Union<[Unknown, Literal<null>]>>;
}, false>;
export type MinecraftFunctionArgumentDetails = Static<typeof MinecraftFunctionArgumentDetailsRecord>;
export declare const MinecraftFunctionArgumentRecord: Intersect<[Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    type: Runtype<MinecraftTypeHelper>;
    details: Optional<Union<[Record<{
        default_value: Optional<Union<[Unknown, Literal<null>]>>;
        min_value: Optional<Union<[Unknown, Literal<null>]>>;
        max_value: Optional<Union<[Unknown, Literal<null>]>>;
        supported_values: Optional<Union<[Unknown, Literal<null>]>>;
    }, false>, Literal<null>]>>;
    min_added: Optional<Boolean>;
    min_changed: Optional<Boolean>;
    min_removed: Optional<Boolean>;
    max_added: Optional<Boolean>;
    max_changed: Optional<Boolean>;
    max_removed: Optional<Boolean>;
    argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    argument_valid_values: Optional<Union<[Array<Record<{
        argument_valid_value: Union<[String, Number]>;
        argument_valid_value_end: Boolean;
    }, false>, false>, Literal<null>]>>;
}, false>]>;
export type MinecraftFunctionArgument = Static<typeof MinecraftFunctionArgumentRecord>;
export declare const MinecraftFunctionRecord: Intersect<[Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    is_constructor: Boolean;
    is_static: Optional<Union<[Boolean, Literal<null>]>>;
    return_type: Runtype<MinecraftTypeHelper>;
    arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        details: Optional<Union<[Record<{
            default_value: Optional<Union<[Unknown, Literal<null>]>>;
            min_value: Optional<Union<[Unknown, Literal<null>]>>;
            max_value: Optional<Union<[Unknown, Literal<null>]>>;
            supported_values: Optional<Union<[Unknown, Literal<null>]>>;
        }, false>, Literal<null>]>>;
        min_added: Optional<Boolean>;
        min_changed: Optional<Boolean>;
        min_removed: Optional<Boolean>;
        max_added: Optional<Boolean>;
        max_changed: Optional<Boolean>;
        max_removed: Optional<Boolean>;
        argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        argument_valid_values: Optional<Union<[Array<Record<{
            argument_valid_value: Union<[String, Number]>;
            argument_valid_value_end: Boolean;
        }, false>, false>, Literal<null>]>>;
    }, false>]>, false>;
    disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
    runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
    is_member: Optional<Boolean>;
    function_name: Optional<Union<[String, Literal<null>]>>;
    function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    stable_only: Optional<Boolean>;
    call_privilege: Optional<Array<Record<{
        name: String;
    }, false>, false>>;
    call_allowed_in_early_execution: Optional<Boolean>;
    call_disallowed_in_restricted_execution: Optional<Boolean>;
    return_type_has_closure_privilege_type_comments: Optional<Boolean>;
    return_type_closure_privilege_type_name: Optional<String>;
}, false>]>;
export type MinecraftFunction = Static<typeof MinecraftFunctionRecord>;
export declare function hasFunctions(obj: object): obj is {
    functions: MinecraftFunction[];
};
export declare const MinecraftErrorRecord: Intersect<[Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    type: Runtype<MinecraftTypeHelper>;
    functions: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        is_constructor: Boolean;
        is_static: Optional<Union<[Boolean, Literal<null>]>>;
        return_type: Runtype<MinecraftTypeHelper>;
        arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            details: Optional<Union<[Record<{
                default_value: Optional<Union<[Unknown, Literal<null>]>>;
                min_value: Optional<Union<[Unknown, Literal<null>]>>;
                max_value: Optional<Union<[Unknown, Literal<null>]>>;
                supported_values: Optional<Union<[Unknown, Literal<null>]>>;
            }, false>, Literal<null>]>>;
            min_added: Optional<Boolean>;
            min_changed: Optional<Boolean>;
            min_removed: Optional<Boolean>;
            max_added: Optional<Boolean>;
            max_changed: Optional<Boolean>;
            max_removed: Optional<Boolean>;
            argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            argument_valid_values: Optional<Union<[Array<Record<{
                argument_valid_value: Union<[String, Number]>;
                argument_valid_value_end: Boolean;
            }, false>, false>, Literal<null>]>>;
        }, false>]>, false>;
        disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
        runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Boolean>;
        function_name: Optional<Union<[String, Literal<null>]>>;
        function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        stable_only: Optional<Boolean>;
        call_privilege: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        call_allowed_in_early_execution: Optional<Boolean>;
        call_disallowed_in_restricted_execution: Optional<Boolean>;
        return_type_has_closure_privilege_type_comments: Optional<Boolean>;
        return_type_closure_privilege_type_name: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    properties: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        is_read_only: Boolean;
        min_value: Optional<Union<[Unknown, Literal<null>]>>;
        max_value: Optional<Union<[Unknown, Literal<null>]>>;
        is_baked: Optional<Boolean>;
        default_value: Optional<Union<[Unknown, Literal<null>]>>;
        min_added: Optional<Boolean>;
        min_changed: Optional<Boolean>;
        min_removed: Optional<Boolean>;
        max_added: Optional<Boolean>;
        max_changed: Optional<Boolean>;
        max_removed: Optional<Boolean>;
        max_length: Optional<Union<[Number, Literal<null>]>>;
        max_length_added: Optional<Boolean>;
        max_length_changed: Optional<Boolean>;
        max_length_removed: Optional<Boolean>;
        property_name: Optional<Union<[String, Literal<null>]>>;
        property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Boolean>;
        get_privilege: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        set_privilege: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        get_allowed_in_early_execution: Optional<Boolean>;
        set_allowed_in_early_execution: Optional<Boolean>;
        get_disallowed_in_restricted_execution: Optional<Boolean>;
        set_disallowed_in_restricted_execution: Optional<Boolean>;
    }, false>]>, false>, Literal<null>]>>;
    base_types: Optional<Union<[Array<Runtype<MinecraftTypeHelper>, false>, Literal<null>]>>;
    from_module: Optional<Union<[Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        version: String;
        version_bookmark_name: Optional<String>;
        version_selector: Optional<String>;
    }, false>, Record<{
        uuid: Optional<String>;
        is_external_module: Optional<Boolean>;
        prior_version: Optional<String>;
        folder_path: Optional<String>;
    }, false>]>, Literal<null>]>>;
    class_name: Optional<Union<[String, Literal<null>]>>;
    class_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    has_constructor: Optional<Union<[Boolean, Literal<null>]>>;
    has_member_functions: Optional<Union<[Boolean, Literal<null>]>>;
    show_prior_warning: Optional<Boolean>;
    prior_link: Optional<String>;
}, false>]>;
export type MinecraftError = Static<typeof MinecraftErrorRecord>;
export declare function hasErrors(obj: object): obj is {
    errors: MinecraftError[];
};
export declare const MinecraftClassRecord: Intersect<[Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    type: Runtype<MinecraftTypeHelper>;
    functions: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        is_constructor: Boolean;
        is_static: Optional<Union<[Boolean, Literal<null>]>>;
        return_type: Runtype<MinecraftTypeHelper>;
        arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            details: Optional<Union<[Record<{
                default_value: Optional<Union<[Unknown, Literal<null>]>>;
                min_value: Optional<Union<[Unknown, Literal<null>]>>;
                max_value: Optional<Union<[Unknown, Literal<null>]>>;
                supported_values: Optional<Union<[Unknown, Literal<null>]>>;
            }, false>, Literal<null>]>>;
            min_added: Optional<Boolean>;
            min_changed: Optional<Boolean>;
            min_removed: Optional<Boolean>;
            max_added: Optional<Boolean>;
            max_changed: Optional<Boolean>;
            max_removed: Optional<Boolean>;
            argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            argument_valid_values: Optional<Union<[Array<Record<{
                argument_valid_value: Union<[String, Number]>;
                argument_valid_value_end: Boolean;
            }, false>, false>, Literal<null>]>>;
        }, false>]>, false>;
        disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
        runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Boolean>;
        function_name: Optional<Union<[String, Literal<null>]>>;
        function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        stable_only: Optional<Boolean>;
        call_privilege: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        call_allowed_in_early_execution: Optional<Boolean>;
        call_disallowed_in_restricted_execution: Optional<Boolean>;
        return_type_has_closure_privilege_type_comments: Optional<Boolean>;
        return_type_closure_privilege_type_name: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    properties: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        is_read_only: Boolean;
        min_value: Optional<Union<[Unknown, Literal<null>]>>;
        max_value: Optional<Union<[Unknown, Literal<null>]>>;
        is_baked: Optional<Boolean>;
        default_value: Optional<Union<[Unknown, Literal<null>]>>;
        min_added: Optional<Boolean>;
        min_changed: Optional<Boolean>;
        min_removed: Optional<Boolean>;
        max_added: Optional<Boolean>;
        max_changed: Optional<Boolean>;
        max_removed: Optional<Boolean>;
        max_length: Optional<Union<[Number, Literal<null>]>>;
        max_length_added: Optional<Boolean>;
        max_length_changed: Optional<Boolean>;
        max_length_removed: Optional<Boolean>;
        property_name: Optional<Union<[String, Literal<null>]>>;
        property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Boolean>;
        get_privilege: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        set_privilege: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        get_allowed_in_early_execution: Optional<Boolean>;
        set_allowed_in_early_execution: Optional<Boolean>;
        get_disallowed_in_restricted_execution: Optional<Boolean>;
        set_disallowed_in_restricted_execution: Optional<Boolean>;
    }, false>]>, false>, Literal<null>]>>;
    constants: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        is_read_only: Literal<true>;
        is_static: Literal<true>;
        value: Optional<Unknown>;
        property_name: Optional<String>;
        property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Literal<true>>;
        constant_value: Optional<Record<{
            value: Unknown;
        }, false>>;
    }, false>]>, false>, Literal<null>]>>;
    runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
    base_types: Optional<Union<[Array<Runtype<MinecraftTypeHelper>, false>, Literal<null>]>>;
    derived_types: Optional<Union<[Array<Runtype<MinecraftTypeHelper>, false>, Literal<null>]>>;
    iterator: Optional<Union<[Runtype<MinecraftTypeHelper>, Literal<null>]>>;
    from_module: Optional<Union<[Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        version: String;
        version_bookmark_name: Optional<String>;
        version_selector: Optional<String>;
    }, false>, Record<{
        uuid: Optional<String>;
        is_external_module: Optional<Boolean>;
        prior_version: Optional<String>;
        folder_path: Optional<String>;
    }, false>]>, Literal<null>]>>;
    class_name: Optional<Union<[String, Literal<null>]>>;
    class_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    has_constructor: Optional<Union<[Boolean, Literal<null>]>>;
    has_member_functions: Optional<Union<[Boolean, Literal<null>]>>;
    has_member_constants: Optional<Union<[Boolean, Literal<null>]>>;
    show_prior_warning: Optional<Boolean>;
    prior_link: Optional<String>;
}, false>]>;
export type MinecraftClass = Static<typeof MinecraftClassRecord>;
export declare function hasClasses(obj: object): obj is {
    classes: MinecraftClass[];
};
export declare const MinecraftInterfaceRecord: Intersect<[Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    type: Runtype<MinecraftTypeHelper>;
    runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
    functions: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        is_constructor: Boolean;
        is_static: Optional<Union<[Boolean, Literal<null>]>>;
        return_type: Runtype<MinecraftTypeHelper>;
        arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            details: Optional<Union<[Record<{
                default_value: Optional<Union<[Unknown, Literal<null>]>>;
                min_value: Optional<Union<[Unknown, Literal<null>]>>;
                max_value: Optional<Union<[Unknown, Literal<null>]>>;
                supported_values: Optional<Union<[Unknown, Literal<null>]>>;
            }, false>, Literal<null>]>>;
            min_added: Optional<Boolean>;
            min_changed: Optional<Boolean>;
            min_removed: Optional<Boolean>;
            max_added: Optional<Boolean>;
            max_changed: Optional<Boolean>;
            max_removed: Optional<Boolean>;
            argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            argument_valid_values: Optional<Union<[Array<Record<{
                argument_valid_value: Union<[String, Number]>;
                argument_valid_value_end: Boolean;
            }, false>, false>, Literal<null>]>>;
        }, false>]>, false>;
        disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
        runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Boolean>;
        function_name: Optional<Union<[String, Literal<null>]>>;
        function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        stable_only: Optional<Boolean>;
        call_privilege: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        call_allowed_in_early_execution: Optional<Boolean>;
        call_disallowed_in_restricted_execution: Optional<Boolean>;
        return_type_has_closure_privilege_type_comments: Optional<Boolean>;
        return_type_closure_privilege_type_name: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    properties: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        is_read_only: Boolean;
        min_value: Optional<Union<[Unknown, Literal<null>]>>;
        max_value: Optional<Union<[Unknown, Literal<null>]>>;
        is_baked: Optional<Boolean>;
        default_value: Optional<Union<[Unknown, Literal<null>]>>;
        min_added: Optional<Boolean>;
        min_changed: Optional<Boolean>;
        min_removed: Optional<Boolean>;
        max_added: Optional<Boolean>;
        max_changed: Optional<Boolean>;
        max_removed: Optional<Boolean>;
        max_length: Optional<Union<[Number, Literal<null>]>>;
        max_length_added: Optional<Boolean>;
        max_length_changed: Optional<Boolean>;
        max_length_removed: Optional<Boolean>;
        property_name: Optional<Union<[String, Literal<null>]>>;
        property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Boolean>;
        get_privilege: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        set_privilege: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        get_allowed_in_early_execution: Optional<Boolean>;
        set_allowed_in_early_execution: Optional<Boolean>;
        get_disallowed_in_restricted_execution: Optional<Boolean>;
        set_disallowed_in_restricted_execution: Optional<Boolean>;
    }, false>]>, false>, Literal<null>]>>;
    from_module: Optional<Union<[Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        version: String;
        version_bookmark_name: Optional<String>;
        version_selector: Optional<String>;
    }, false>, Record<{
        uuid: Optional<String>;
        is_external_module: Optional<Boolean>;
        prior_version: Optional<String>;
        folder_path: Optional<String>;
    }, false>]>, Literal<null>]>>;
    class_name: Optional<Union<[String, Literal<null>]>>;
    class_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    is_interface: Optional<Literal<true>>;
    has_member_functions: Optional<Union<[Boolean, Literal<null>]>>;
    show_prior_warning: Optional<Boolean>;
    prior_link: Optional<String>;
}, false>]>;
export type MinecraftInterface = Static<typeof MinecraftInterfaceRecord>;
export declare function hasInterfaces(obj: object): obj is {
    interfaces: MinecraftInterface[];
};
export declare const MinecraftTypeMappingRecord: Intersect<[Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    value: String;
}, false>]>;
export type MinecraftTypeMapping = Static<typeof MinecraftTypeMappingRecord>;
export declare enum MinecraftTypeAliasTypes {
    TypeMap = "type_map",
    ScriptGenerated = "script_generated"
}
export declare const MinecraftTypeAliasTypesRecord: Union<[Literal<MinecraftTypeAliasTypes.TypeMap>, Literal<MinecraftTypeAliasTypes.ScriptGenerated>]>;
export declare const MinecraftTypeAliasRecord: Intersect<[Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    alias_type: Optional<Union<[Union<[Literal<MinecraftTypeAliasTypes.TypeMap>, Literal<MinecraftTypeAliasTypes.ScriptGenerated>]>, Literal<null>]>>;
    type: Optional<Union<[Runtype<MinecraftTypeHelper>, Literal<null>]>>;
    mappings: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        value: String;
    }, false>]>, false>, Literal<null>]>>;
    from_module: Optional<Union<[Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        version: String;
        version_bookmark_name: Optional<String>;
        version_selector: Optional<String>;
    }, false>, Record<{
        uuid: Optional<String>;
        is_external_module: Optional<Boolean>;
        prior_version: Optional<String>;
        folder_path: Optional<String>;
    }, false>]>, Literal<null>]>>;
    alias_name: Optional<Union<[String, Literal<null>]>>;
    is_type_map: Optional<Union<[Boolean, Literal<null>]>>;
    alias_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    show_prior_warning: Optional<Boolean>;
    prior_link: Optional<String>;
}, false>]>;
export type MinecraftTypeAlias = Static<typeof MinecraftTypeAliasRecord>;
export declare function hasTypeAliases(obj: object): obj is {
    type_aliases: MinecraftTypeAlias[];
};
export declare const MinecraftScriptCoreExportsRecord: Record<{
    errors: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        functions: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            is_constructor: Boolean;
            is_static: Optional<Union<[Boolean, Literal<null>]>>;
            return_type: Runtype<MinecraftTypeHelper>;
            arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
                has_comments: Optional<Boolean>;
            }, false>, Record<{
                has_changes: Optional<Boolean>;
                has_defaults: Optional<Boolean>;
                has_minimum: Optional<Boolean>;
                has_maximum: Optional<Boolean>;
                has_bounds: Optional<Boolean>;
                has_max_length: Optional<Boolean>;
                has_errors: Optional<Boolean>;
                prerelease: Optional<String>;
                is_prerelease: Optional<Boolean>;
                is_deprecated: Optional<Boolean>;
                deprecated_version: Optional<String>;
                has_runtime_conditions: Optional<Boolean>;
                has_closure_privilege_type_comments: Optional<Boolean>;
                has_privilege_comments: Optional<Boolean>;
                ts_has_comments: Optional<Boolean>;
                ts_has_remarks: Optional<Boolean>;
                msdocs_has_comments: Optional<Boolean>;
            }, false>]>, Record<{
                is_script_generated: Optional<Boolean>;
                raw_script_text: Optional<String>;
                raw_tsdoc_text: Optional<String>;
            }, false>, Record<{
                examples: Optional<Array<Intersect<[Record<{
                    name: String;
                    bookmark_name: Optional<String>;
                    filepath_name: Optional<String>;
                    variable_name: Optional<String>;
                }, false>, Record<{
                    code: Record<{
                        text: Array<String, false>;
                        escaped_text: Array<String, false>;
                    }, false>;
                }, false>]>, false>>;
                deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                closure_privilege_type_name: Optional<String>;
            }, false>]>, Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                type: Runtype<MinecraftTypeHelper>;
                details: Optional<Union<[Record<{
                    default_value: Optional<Union<[Unknown, Literal<null>]>>;
                    min_value: Optional<Union<[Unknown, Literal<null>]>>;
                    max_value: Optional<Union<[Unknown, Literal<null>]>>;
                    supported_values: Optional<Union<[Unknown, Literal<null>]>>;
                }, false>, Literal<null>]>>;
                min_added: Optional<Boolean>;
                min_changed: Optional<Boolean>;
                min_removed: Optional<Boolean>;
                max_added: Optional<Boolean>;
                max_changed: Optional<Boolean>;
                max_removed: Optional<Boolean>;
                argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                argument_valid_values: Optional<Union<[Array<Record<{
                    argument_valid_value: Union<[String, Number]>;
                    argument_valid_value_end: Boolean;
                }, false>, false>, Literal<null>]>>;
            }, false>]>, false>;
            disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
            runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            function_name: Optional<Union<[String, Literal<null>]>>;
            function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            stable_only: Optional<Boolean>;
            call_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            call_allowed_in_early_execution: Optional<Boolean>;
            call_disallowed_in_restricted_execution: Optional<Boolean>;
            return_type_has_closure_privilege_type_comments: Optional<Boolean>;
            return_type_closure_privilege_type_name: Optional<String>;
        }, false>]>, false>, Literal<null>]>>;
        properties: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            is_read_only: Boolean;
            min_value: Optional<Union<[Unknown, Literal<null>]>>;
            max_value: Optional<Union<[Unknown, Literal<null>]>>;
            is_baked: Optional<Boolean>;
            default_value: Optional<Union<[Unknown, Literal<null>]>>;
            min_added: Optional<Boolean>;
            min_changed: Optional<Boolean>;
            min_removed: Optional<Boolean>;
            max_added: Optional<Boolean>;
            max_changed: Optional<Boolean>;
            max_removed: Optional<Boolean>;
            max_length: Optional<Union<[Number, Literal<null>]>>;
            max_length_added: Optional<Boolean>;
            max_length_changed: Optional<Boolean>;
            max_length_removed: Optional<Boolean>;
            property_name: Optional<Union<[String, Literal<null>]>>;
            property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            get_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            set_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            get_allowed_in_early_execution: Optional<Boolean>;
            set_allowed_in_early_execution: Optional<Boolean>;
            get_disallowed_in_restricted_execution: Optional<Boolean>;
            set_disallowed_in_restricted_execution: Optional<Boolean>;
        }, false>]>, false>, Literal<null>]>>;
        base_types: Optional<Union<[Array<Runtype<MinecraftTypeHelper>, false>, Literal<null>]>>;
        from_module: Optional<Union<[Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>, Literal<null>]>>;
        class_name: Optional<Union<[String, Literal<null>]>>;
        class_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        has_constructor: Optional<Union<[Boolean, Literal<null>]>>;
        has_member_functions: Optional<Union<[Boolean, Literal<null>]>>;
        show_prior_warning: Optional<Boolean>;
        prior_link: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    classes: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        functions: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            is_constructor: Boolean;
            is_static: Optional<Union<[Boolean, Literal<null>]>>;
            return_type: Runtype<MinecraftTypeHelper>;
            arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
                has_comments: Optional<Boolean>;
            }, false>, Record<{
                has_changes: Optional<Boolean>;
                has_defaults: Optional<Boolean>;
                has_minimum: Optional<Boolean>;
                has_maximum: Optional<Boolean>;
                has_bounds: Optional<Boolean>;
                has_max_length: Optional<Boolean>;
                has_errors: Optional<Boolean>;
                prerelease: Optional<String>;
                is_prerelease: Optional<Boolean>;
                is_deprecated: Optional<Boolean>;
                deprecated_version: Optional<String>;
                has_runtime_conditions: Optional<Boolean>;
                has_closure_privilege_type_comments: Optional<Boolean>;
                has_privilege_comments: Optional<Boolean>;
                ts_has_comments: Optional<Boolean>;
                ts_has_remarks: Optional<Boolean>;
                msdocs_has_comments: Optional<Boolean>;
            }, false>]>, Record<{
                is_script_generated: Optional<Boolean>;
                raw_script_text: Optional<String>;
                raw_tsdoc_text: Optional<String>;
            }, false>, Record<{
                examples: Optional<Array<Intersect<[Record<{
                    name: String;
                    bookmark_name: Optional<String>;
                    filepath_name: Optional<String>;
                    variable_name: Optional<String>;
                }, false>, Record<{
                    code: Record<{
                        text: Array<String, false>;
                        escaped_text: Array<String, false>;
                    }, false>;
                }, false>]>, false>>;
                deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                closure_privilege_type_name: Optional<String>;
            }, false>]>, Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                type: Runtype<MinecraftTypeHelper>;
                details: Optional<Union<[Record<{
                    default_value: Optional<Union<[Unknown, Literal<null>]>>;
                    min_value: Optional<Union<[Unknown, Literal<null>]>>;
                    max_value: Optional<Union<[Unknown, Literal<null>]>>;
                    supported_values: Optional<Union<[Unknown, Literal<null>]>>;
                }, false>, Literal<null>]>>;
                min_added: Optional<Boolean>;
                min_changed: Optional<Boolean>;
                min_removed: Optional<Boolean>;
                max_added: Optional<Boolean>;
                max_changed: Optional<Boolean>;
                max_removed: Optional<Boolean>;
                argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                argument_valid_values: Optional<Union<[Array<Record<{
                    argument_valid_value: Union<[String, Number]>;
                    argument_valid_value_end: Boolean;
                }, false>, false>, Literal<null>]>>;
            }, false>]>, false>;
            disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
            runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            function_name: Optional<Union<[String, Literal<null>]>>;
            function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            stable_only: Optional<Boolean>;
            call_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            call_allowed_in_early_execution: Optional<Boolean>;
            call_disallowed_in_restricted_execution: Optional<Boolean>;
            return_type_has_closure_privilege_type_comments: Optional<Boolean>;
            return_type_closure_privilege_type_name: Optional<String>;
        }, false>]>, false>, Literal<null>]>>;
        properties: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            is_read_only: Boolean;
            min_value: Optional<Union<[Unknown, Literal<null>]>>;
            max_value: Optional<Union<[Unknown, Literal<null>]>>;
            is_baked: Optional<Boolean>;
            default_value: Optional<Union<[Unknown, Literal<null>]>>;
            min_added: Optional<Boolean>;
            min_changed: Optional<Boolean>;
            min_removed: Optional<Boolean>;
            max_added: Optional<Boolean>;
            max_changed: Optional<Boolean>;
            max_removed: Optional<Boolean>;
            max_length: Optional<Union<[Number, Literal<null>]>>;
            max_length_added: Optional<Boolean>;
            max_length_changed: Optional<Boolean>;
            max_length_removed: Optional<Boolean>;
            property_name: Optional<Union<[String, Literal<null>]>>;
            property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            get_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            set_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            get_allowed_in_early_execution: Optional<Boolean>;
            set_allowed_in_early_execution: Optional<Boolean>;
            get_disallowed_in_restricted_execution: Optional<Boolean>;
            set_disallowed_in_restricted_execution: Optional<Boolean>;
        }, false>]>, false>, Literal<null>]>>;
        constants: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            is_read_only: Literal<true>;
            is_static: Literal<true>;
            value: Optional<Unknown>;
            property_name: Optional<String>;
            property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Literal<true>>;
            constant_value: Optional<Record<{
                value: Unknown;
            }, false>>;
        }, false>]>, false>, Literal<null>]>>;
        runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
        base_types: Optional<Union<[Array<Runtype<MinecraftTypeHelper>, false>, Literal<null>]>>;
        derived_types: Optional<Union<[Array<Runtype<MinecraftTypeHelper>, false>, Literal<null>]>>;
        iterator: Optional<Union<[Runtype<MinecraftTypeHelper>, Literal<null>]>>;
        from_module: Optional<Union<[Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>, Literal<null>]>>;
        class_name: Optional<Union<[String, Literal<null>]>>;
        class_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        has_constructor: Optional<Union<[Boolean, Literal<null>]>>;
        has_member_functions: Optional<Union<[Boolean, Literal<null>]>>;
        has_member_constants: Optional<Union<[Boolean, Literal<null>]>>;
        show_prior_warning: Optional<Boolean>;
        prior_link: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    functions: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        is_constructor: Boolean;
        is_static: Optional<Union<[Boolean, Literal<null>]>>;
        return_type: Runtype<MinecraftTypeHelper>;
        arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            details: Optional<Union<[Record<{
                default_value: Optional<Union<[Unknown, Literal<null>]>>;
                min_value: Optional<Union<[Unknown, Literal<null>]>>;
                max_value: Optional<Union<[Unknown, Literal<null>]>>;
                supported_values: Optional<Union<[Unknown, Literal<null>]>>;
            }, false>, Literal<null>]>>;
            min_added: Optional<Boolean>;
            min_changed: Optional<Boolean>;
            min_removed: Optional<Boolean>;
            max_added: Optional<Boolean>;
            max_changed: Optional<Boolean>;
            max_removed: Optional<Boolean>;
            argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            argument_valid_values: Optional<Union<[Array<Record<{
                argument_valid_value: Union<[String, Number]>;
                argument_valid_value_end: Boolean;
            }, false>, false>, Literal<null>]>>;
        }, false>]>, false>;
        disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
        runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Boolean>;
        function_name: Optional<Union<[String, Literal<null>]>>;
        function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        stable_only: Optional<Boolean>;
        call_privilege: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        call_allowed_in_early_execution: Optional<Boolean>;
        call_disallowed_in_restricted_execution: Optional<Boolean>;
        return_type_has_closure_privilege_type_comments: Optional<Boolean>;
        return_type_closure_privilege_type_name: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    objects: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    }, false>]>, false>, Literal<null>]>>;
    interfaces: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
        functions: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            is_constructor: Boolean;
            is_static: Optional<Union<[Boolean, Literal<null>]>>;
            return_type: Runtype<MinecraftTypeHelper>;
            arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
                has_comments: Optional<Boolean>;
            }, false>, Record<{
                has_changes: Optional<Boolean>;
                has_defaults: Optional<Boolean>;
                has_minimum: Optional<Boolean>;
                has_maximum: Optional<Boolean>;
                has_bounds: Optional<Boolean>;
                has_max_length: Optional<Boolean>;
                has_errors: Optional<Boolean>;
                prerelease: Optional<String>;
                is_prerelease: Optional<Boolean>;
                is_deprecated: Optional<Boolean>;
                deprecated_version: Optional<String>;
                has_runtime_conditions: Optional<Boolean>;
                has_closure_privilege_type_comments: Optional<Boolean>;
                has_privilege_comments: Optional<Boolean>;
                ts_has_comments: Optional<Boolean>;
                ts_has_remarks: Optional<Boolean>;
                msdocs_has_comments: Optional<Boolean>;
            }, false>]>, Record<{
                is_script_generated: Optional<Boolean>;
                raw_script_text: Optional<String>;
                raw_tsdoc_text: Optional<String>;
            }, false>, Record<{
                examples: Optional<Array<Intersect<[Record<{
                    name: String;
                    bookmark_name: Optional<String>;
                    filepath_name: Optional<String>;
                    variable_name: Optional<String>;
                }, false>, Record<{
                    code: Record<{
                        text: Array<String, false>;
                        escaped_text: Array<String, false>;
                    }, false>;
                }, false>]>, false>>;
                deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                closure_privilege_type_name: Optional<String>;
            }, false>]>, Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                type: Runtype<MinecraftTypeHelper>;
                details: Optional<Union<[Record<{
                    default_value: Optional<Union<[Unknown, Literal<null>]>>;
                    min_value: Optional<Union<[Unknown, Literal<null>]>>;
                    max_value: Optional<Union<[Unknown, Literal<null>]>>;
                    supported_values: Optional<Union<[Unknown, Literal<null>]>>;
                }, false>, Literal<null>]>>;
                min_added: Optional<Boolean>;
                min_changed: Optional<Boolean>;
                min_removed: Optional<Boolean>;
                max_added: Optional<Boolean>;
                max_changed: Optional<Boolean>;
                max_removed: Optional<Boolean>;
                argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                argument_valid_values: Optional<Union<[Array<Record<{
                    argument_valid_value: Union<[String, Number]>;
                    argument_valid_value_end: Boolean;
                }, false>, false>, Literal<null>]>>;
            }, false>]>, false>;
            disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
            runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            function_name: Optional<Union<[String, Literal<null>]>>;
            function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            stable_only: Optional<Boolean>;
            call_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            call_allowed_in_early_execution: Optional<Boolean>;
            call_disallowed_in_restricted_execution: Optional<Boolean>;
            return_type_has_closure_privilege_type_comments: Optional<Boolean>;
            return_type_closure_privilege_type_name: Optional<String>;
        }, false>]>, false>, Literal<null>]>>;
        properties: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            is_read_only: Boolean;
            min_value: Optional<Union<[Unknown, Literal<null>]>>;
            max_value: Optional<Union<[Unknown, Literal<null>]>>;
            is_baked: Optional<Boolean>;
            default_value: Optional<Union<[Unknown, Literal<null>]>>;
            min_added: Optional<Boolean>;
            min_changed: Optional<Boolean>;
            min_removed: Optional<Boolean>;
            max_added: Optional<Boolean>;
            max_changed: Optional<Boolean>;
            max_removed: Optional<Boolean>;
            max_length: Optional<Union<[Number, Literal<null>]>>;
            max_length_added: Optional<Boolean>;
            max_length_changed: Optional<Boolean>;
            max_length_removed: Optional<Boolean>;
            property_name: Optional<Union<[String, Literal<null>]>>;
            property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            get_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            set_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            get_allowed_in_early_execution: Optional<Boolean>;
            set_allowed_in_early_execution: Optional<Boolean>;
            get_disallowed_in_restricted_execution: Optional<Boolean>;
            set_disallowed_in_restricted_execution: Optional<Boolean>;
        }, false>]>, false>, Literal<null>]>>;
        from_module: Optional<Union<[Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>, Literal<null>]>>;
        class_name: Optional<Union<[String, Literal<null>]>>;
        class_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_interface: Optional<Literal<true>>;
        has_member_functions: Optional<Union<[Boolean, Literal<null>]>>;
        show_prior_warning: Optional<Boolean>;
        prior_link: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    enums: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        constants: Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            is_read_only: Literal<true>;
            is_static: Literal<true>;
            value: Optional<Unknown>;
            property_name: Optional<String>;
            property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Literal<true>>;
            constant_value: Optional<Record<{
                value: Unknown;
            }, false>>;
        }, false>]>, false>;
        from_module: Optional<Union<[Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>, Literal<null>]>>;
        is_enum: Optional<Literal<true>>;
        enum_name: Optional<Union<[String, Literal<null>]>>;
        enum_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        show_prior_warning: Optional<Boolean>;
        prior_link: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    constants: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        is_read_only: Literal<true>;
        is_static: Literal<true>;
        value: Optional<Unknown>;
        property_name: Optional<String>;
        property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Literal<true>>;
        constant_value: Optional<Record<{
            value: Unknown;
        }, false>>;
    }, false>]>, false>, Literal<null>]>>;
    type_aliases: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        alias_type: Optional<Union<[Union<[Literal<MinecraftTypeAliasTypes.TypeMap>, Literal<MinecraftTypeAliasTypes.ScriptGenerated>]>, Literal<null>]>>;
        type: Optional<Union<[Runtype<MinecraftTypeHelper>, Literal<null>]>>;
        mappings: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            value: String;
        }, false>]>, false>, Literal<null>]>>;
        from_module: Optional<Union<[Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>, Literal<null>]>>;
        alias_name: Optional<Union<[String, Literal<null>]>>;
        is_type_map: Optional<Union<[Boolean, Literal<null>]>>;
        alias_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        show_prior_warning: Optional<Boolean>;
        prior_link: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
}, false>;
export type MinecraftScriptCoreExports = Static<typeof MinecraftScriptCoreExportsRecord>;
export declare const MinecraftParentModuleRecord: Record<{
    name: String;
    uuid: Optional<String>;
    version: Optional<String>;
}, false>;
export type MinecraftParentModule = Static<typeof MinecraftParentModuleRecord>;
export declare const MinecraftScriptModuleRecord: Intersect<[Record<{
    name: String;
    minecraft_version: String;
    module_type: Union<[Literal<"script">, Literal<"commands">, Literal<"after_events_ordering">, Literal<"vanilla_data">, Literal<"molang">]>;
    module_name: Optional<String>;
}, false>, Intersect<[Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    has_changes: Optional<Boolean>;
    has_defaults: Optional<Boolean>;
    has_minimum: Optional<Boolean>;
    has_maximum: Optional<Boolean>;
    has_bounds: Optional<Boolean>;
    has_max_length: Optional<Boolean>;
    has_errors: Optional<Boolean>;
    prerelease: Optional<String>;
    is_prerelease: Optional<Boolean>;
    is_deprecated: Optional<Boolean>;
    deprecated_version: Optional<String>;
    has_runtime_conditions: Optional<Boolean>;
    has_closure_privilege_type_comments: Optional<Boolean>;
    has_privilege_comments: Optional<Boolean>;
    ts_has_comments: Optional<Boolean>;
    ts_has_remarks: Optional<Boolean>;
    msdocs_has_comments: Optional<Boolean>;
}, false>]>, Record<{
    is_script_generated: Optional<Boolean>;
    raw_script_text: Optional<String>;
    raw_tsdoc_text: Optional<String>;
}, false>, Record<{
    examples: Optional<Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        code: Record<{
            text: Array<String, false>;
            escaped_text: Array<String, false>;
        }, false>;
    }, false>]>, false>>;
    deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    closure_privilege_type_name: Optional<String>;
}, false>]>, Record<{
    name: String;
    bookmark_name: Optional<String>;
    filepath_name: Optional<String>;
    variable_name: Optional<String>;
}, false>, Record<{
    version: String;
    version_bookmark_name: Optional<String>;
    version_selector: Optional<String>;
}, false>, Record<{
    errors: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        functions: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            is_constructor: Boolean;
            is_static: Optional<Union<[Boolean, Literal<null>]>>;
            return_type: Runtype<MinecraftTypeHelper>;
            arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
                has_comments: Optional<Boolean>;
            }, false>, Record<{
                has_changes: Optional<Boolean>;
                has_defaults: Optional<Boolean>;
                has_minimum: Optional<Boolean>;
                has_maximum: Optional<Boolean>;
                has_bounds: Optional<Boolean>;
                has_max_length: Optional<Boolean>;
                has_errors: Optional<Boolean>;
                prerelease: Optional<String>;
                is_prerelease: Optional<Boolean>;
                is_deprecated: Optional<Boolean>;
                deprecated_version: Optional<String>;
                has_runtime_conditions: Optional<Boolean>;
                has_closure_privilege_type_comments: Optional<Boolean>;
                has_privilege_comments: Optional<Boolean>;
                ts_has_comments: Optional<Boolean>;
                ts_has_remarks: Optional<Boolean>;
                msdocs_has_comments: Optional<Boolean>;
            }, false>]>, Record<{
                is_script_generated: Optional<Boolean>;
                raw_script_text: Optional<String>;
                raw_tsdoc_text: Optional<String>;
            }, false>, Record<{
                examples: Optional<Array<Intersect<[Record<{
                    name: String;
                    bookmark_name: Optional<String>;
                    filepath_name: Optional<String>;
                    variable_name: Optional<String>;
                }, false>, Record<{
                    code: Record<{
                        text: Array<String, false>;
                        escaped_text: Array<String, false>;
                    }, false>;
                }, false>]>, false>>;
                deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                closure_privilege_type_name: Optional<String>;
            }, false>]>, Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                type: Runtype<MinecraftTypeHelper>;
                details: Optional<Union<[Record<{
                    default_value: Optional<Union<[Unknown, Literal<null>]>>;
                    min_value: Optional<Union<[Unknown, Literal<null>]>>;
                    max_value: Optional<Union<[Unknown, Literal<null>]>>;
                    supported_values: Optional<Union<[Unknown, Literal<null>]>>;
                }, false>, Literal<null>]>>;
                min_added: Optional<Boolean>;
                min_changed: Optional<Boolean>;
                min_removed: Optional<Boolean>;
                max_added: Optional<Boolean>;
                max_changed: Optional<Boolean>;
                max_removed: Optional<Boolean>;
                argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                argument_valid_values: Optional<Union<[Array<Record<{
                    argument_valid_value: Union<[String, Number]>;
                    argument_valid_value_end: Boolean;
                }, false>, false>, Literal<null>]>>;
            }, false>]>, false>;
            disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
            runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            function_name: Optional<Union<[String, Literal<null>]>>;
            function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            stable_only: Optional<Boolean>;
            call_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            call_allowed_in_early_execution: Optional<Boolean>;
            call_disallowed_in_restricted_execution: Optional<Boolean>;
            return_type_has_closure_privilege_type_comments: Optional<Boolean>;
            return_type_closure_privilege_type_name: Optional<String>;
        }, false>]>, false>, Literal<null>]>>;
        properties: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            is_read_only: Boolean;
            min_value: Optional<Union<[Unknown, Literal<null>]>>;
            max_value: Optional<Union<[Unknown, Literal<null>]>>;
            is_baked: Optional<Boolean>;
            default_value: Optional<Union<[Unknown, Literal<null>]>>;
            min_added: Optional<Boolean>;
            min_changed: Optional<Boolean>;
            min_removed: Optional<Boolean>;
            max_added: Optional<Boolean>;
            max_changed: Optional<Boolean>;
            max_removed: Optional<Boolean>;
            max_length: Optional<Union<[Number, Literal<null>]>>;
            max_length_added: Optional<Boolean>;
            max_length_changed: Optional<Boolean>;
            max_length_removed: Optional<Boolean>;
            property_name: Optional<Union<[String, Literal<null>]>>;
            property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            get_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            set_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            get_allowed_in_early_execution: Optional<Boolean>;
            set_allowed_in_early_execution: Optional<Boolean>;
            get_disallowed_in_restricted_execution: Optional<Boolean>;
            set_disallowed_in_restricted_execution: Optional<Boolean>;
        }, false>]>, false>, Literal<null>]>>;
        base_types: Optional<Union<[Array<Runtype<MinecraftTypeHelper>, false>, Literal<null>]>>;
        from_module: Optional<Union<[Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>, Literal<null>]>>;
        class_name: Optional<Union<[String, Literal<null>]>>;
        class_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        has_constructor: Optional<Union<[Boolean, Literal<null>]>>;
        has_member_functions: Optional<Union<[Boolean, Literal<null>]>>;
        show_prior_warning: Optional<Boolean>;
        prior_link: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    classes: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        functions: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            is_constructor: Boolean;
            is_static: Optional<Union<[Boolean, Literal<null>]>>;
            return_type: Runtype<MinecraftTypeHelper>;
            arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
                has_comments: Optional<Boolean>;
            }, false>, Record<{
                has_changes: Optional<Boolean>;
                has_defaults: Optional<Boolean>;
                has_minimum: Optional<Boolean>;
                has_maximum: Optional<Boolean>;
                has_bounds: Optional<Boolean>;
                has_max_length: Optional<Boolean>;
                has_errors: Optional<Boolean>;
                prerelease: Optional<String>;
                is_prerelease: Optional<Boolean>;
                is_deprecated: Optional<Boolean>;
                deprecated_version: Optional<String>;
                has_runtime_conditions: Optional<Boolean>;
                has_closure_privilege_type_comments: Optional<Boolean>;
                has_privilege_comments: Optional<Boolean>;
                ts_has_comments: Optional<Boolean>;
                ts_has_remarks: Optional<Boolean>;
                msdocs_has_comments: Optional<Boolean>;
            }, false>]>, Record<{
                is_script_generated: Optional<Boolean>;
                raw_script_text: Optional<String>;
                raw_tsdoc_text: Optional<String>;
            }, false>, Record<{
                examples: Optional<Array<Intersect<[Record<{
                    name: String;
                    bookmark_name: Optional<String>;
                    filepath_name: Optional<String>;
                    variable_name: Optional<String>;
                }, false>, Record<{
                    code: Record<{
                        text: Array<String, false>;
                        escaped_text: Array<String, false>;
                    }, false>;
                }, false>]>, false>>;
                deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                closure_privilege_type_name: Optional<String>;
            }, false>]>, Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                type: Runtype<MinecraftTypeHelper>;
                details: Optional<Union<[Record<{
                    default_value: Optional<Union<[Unknown, Literal<null>]>>;
                    min_value: Optional<Union<[Unknown, Literal<null>]>>;
                    max_value: Optional<Union<[Unknown, Literal<null>]>>;
                    supported_values: Optional<Union<[Unknown, Literal<null>]>>;
                }, false>, Literal<null>]>>;
                min_added: Optional<Boolean>;
                min_changed: Optional<Boolean>;
                min_removed: Optional<Boolean>;
                max_added: Optional<Boolean>;
                max_changed: Optional<Boolean>;
                max_removed: Optional<Boolean>;
                argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                argument_valid_values: Optional<Union<[Array<Record<{
                    argument_valid_value: Union<[String, Number]>;
                    argument_valid_value_end: Boolean;
                }, false>, false>, Literal<null>]>>;
            }, false>]>, false>;
            disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
            runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            function_name: Optional<Union<[String, Literal<null>]>>;
            function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            stable_only: Optional<Boolean>;
            call_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            call_allowed_in_early_execution: Optional<Boolean>;
            call_disallowed_in_restricted_execution: Optional<Boolean>;
            return_type_has_closure_privilege_type_comments: Optional<Boolean>;
            return_type_closure_privilege_type_name: Optional<String>;
        }, false>]>, false>, Literal<null>]>>;
        properties: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            is_read_only: Boolean;
            min_value: Optional<Union<[Unknown, Literal<null>]>>;
            max_value: Optional<Union<[Unknown, Literal<null>]>>;
            is_baked: Optional<Boolean>;
            default_value: Optional<Union<[Unknown, Literal<null>]>>;
            min_added: Optional<Boolean>;
            min_changed: Optional<Boolean>;
            min_removed: Optional<Boolean>;
            max_added: Optional<Boolean>;
            max_changed: Optional<Boolean>;
            max_removed: Optional<Boolean>;
            max_length: Optional<Union<[Number, Literal<null>]>>;
            max_length_added: Optional<Boolean>;
            max_length_changed: Optional<Boolean>;
            max_length_removed: Optional<Boolean>;
            property_name: Optional<Union<[String, Literal<null>]>>;
            property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            get_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            set_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            get_allowed_in_early_execution: Optional<Boolean>;
            set_allowed_in_early_execution: Optional<Boolean>;
            get_disallowed_in_restricted_execution: Optional<Boolean>;
            set_disallowed_in_restricted_execution: Optional<Boolean>;
        }, false>]>, false>, Literal<null>]>>;
        constants: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            is_read_only: Literal<true>;
            is_static: Literal<true>;
            value: Optional<Unknown>;
            property_name: Optional<String>;
            property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Literal<true>>;
            constant_value: Optional<Record<{
                value: Unknown;
            }, false>>;
        }, false>]>, false>, Literal<null>]>>;
        runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
        base_types: Optional<Union<[Array<Runtype<MinecraftTypeHelper>, false>, Literal<null>]>>;
        derived_types: Optional<Union<[Array<Runtype<MinecraftTypeHelper>, false>, Literal<null>]>>;
        iterator: Optional<Union<[Runtype<MinecraftTypeHelper>, Literal<null>]>>;
        from_module: Optional<Union<[Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>, Literal<null>]>>;
        class_name: Optional<Union<[String, Literal<null>]>>;
        class_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        has_constructor: Optional<Union<[Boolean, Literal<null>]>>;
        has_member_functions: Optional<Union<[Boolean, Literal<null>]>>;
        has_member_constants: Optional<Union<[Boolean, Literal<null>]>>;
        show_prior_warning: Optional<Boolean>;
        prior_link: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    functions: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        is_constructor: Boolean;
        is_static: Optional<Union<[Boolean, Literal<null>]>>;
        return_type: Runtype<MinecraftTypeHelper>;
        arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            details: Optional<Union<[Record<{
                default_value: Optional<Union<[Unknown, Literal<null>]>>;
                min_value: Optional<Union<[Unknown, Literal<null>]>>;
                max_value: Optional<Union<[Unknown, Literal<null>]>>;
                supported_values: Optional<Union<[Unknown, Literal<null>]>>;
            }, false>, Literal<null>]>>;
            min_added: Optional<Boolean>;
            min_changed: Optional<Boolean>;
            min_removed: Optional<Boolean>;
            max_added: Optional<Boolean>;
            max_changed: Optional<Boolean>;
            max_removed: Optional<Boolean>;
            argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            argument_valid_values: Optional<Union<[Array<Record<{
                argument_valid_value: Union<[String, Number]>;
                argument_valid_value_end: Boolean;
            }, false>, false>, Literal<null>]>>;
        }, false>]>, false>;
        disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
        runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Boolean>;
        function_name: Optional<Union<[String, Literal<null>]>>;
        function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        stable_only: Optional<Boolean>;
        call_privilege: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        call_allowed_in_early_execution: Optional<Boolean>;
        call_disallowed_in_restricted_execution: Optional<Boolean>;
        return_type_has_closure_privilege_type_comments: Optional<Boolean>;
        return_type_closure_privilege_type_name: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    objects: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    }, false>]>, false>, Literal<null>]>>;
    interfaces: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
        functions: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            is_constructor: Boolean;
            is_static: Optional<Union<[Boolean, Literal<null>]>>;
            return_type: Runtype<MinecraftTypeHelper>;
            arguments: Array<Intersect<[Intersect<[Intersect<[Record<{
                has_comments: Optional<Boolean>;
            }, false>, Record<{
                has_changes: Optional<Boolean>;
                has_defaults: Optional<Boolean>;
                has_minimum: Optional<Boolean>;
                has_maximum: Optional<Boolean>;
                has_bounds: Optional<Boolean>;
                has_max_length: Optional<Boolean>;
                has_errors: Optional<Boolean>;
                prerelease: Optional<String>;
                is_prerelease: Optional<Boolean>;
                is_deprecated: Optional<Boolean>;
                deprecated_version: Optional<String>;
                has_runtime_conditions: Optional<Boolean>;
                has_closure_privilege_type_comments: Optional<Boolean>;
                has_privilege_comments: Optional<Boolean>;
                ts_has_comments: Optional<Boolean>;
                ts_has_remarks: Optional<Boolean>;
                msdocs_has_comments: Optional<Boolean>;
            }, false>]>, Record<{
                is_script_generated: Optional<Boolean>;
                raw_script_text: Optional<String>;
                raw_tsdoc_text: Optional<String>;
            }, false>, Record<{
                examples: Optional<Array<Intersect<[Record<{
                    name: String;
                    bookmark_name: Optional<String>;
                    filepath_name: Optional<String>;
                    variable_name: Optional<String>;
                }, false>, Record<{
                    code: Record<{
                        text: Array<String, false>;
                        escaped_text: Array<String, false>;
                    }, false>;
                }, false>]>, false>>;
                deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                closure_privilege_type_name: Optional<String>;
            }, false>]>, Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                type: Runtype<MinecraftTypeHelper>;
                details: Optional<Union<[Record<{
                    default_value: Optional<Union<[Unknown, Literal<null>]>>;
                    min_value: Optional<Union<[Unknown, Literal<null>]>>;
                    max_value: Optional<Union<[Unknown, Literal<null>]>>;
                    supported_values: Optional<Union<[Unknown, Literal<null>]>>;
                }, false>, Literal<null>]>>;
                min_added: Optional<Boolean>;
                min_changed: Optional<Boolean>;
                min_removed: Optional<Boolean>;
                max_added: Optional<Boolean>;
                max_changed: Optional<Boolean>;
                max_removed: Optional<Boolean>;
                argument_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
                argument_valid_values: Optional<Union<[Array<Record<{
                    argument_valid_value: Union<[String, Number]>;
                    argument_valid_value_end: Boolean;
                }, false>, false>, Literal<null>]>>;
            }, false>]>, false>;
            disable_unsafe_name_check: Optional<Union<[Boolean, Literal<null>]>>;
            runtime_conditions: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            function_name: Optional<Union<[String, Literal<null>]>>;
            function_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            returns_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            stable_only: Optional<Boolean>;
            call_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            call_allowed_in_early_execution: Optional<Boolean>;
            call_disallowed_in_restricted_execution: Optional<Boolean>;
            return_type_has_closure_privilege_type_comments: Optional<Boolean>;
            return_type_closure_privilege_type_name: Optional<String>;
        }, false>]>, false>, Literal<null>]>>;
        properties: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            is_read_only: Boolean;
            min_value: Optional<Union<[Unknown, Literal<null>]>>;
            max_value: Optional<Union<[Unknown, Literal<null>]>>;
            is_baked: Optional<Boolean>;
            default_value: Optional<Union<[Unknown, Literal<null>]>>;
            min_added: Optional<Boolean>;
            min_changed: Optional<Boolean>;
            min_removed: Optional<Boolean>;
            max_added: Optional<Boolean>;
            max_changed: Optional<Boolean>;
            max_removed: Optional<Boolean>;
            max_length: Optional<Union<[Number, Literal<null>]>>;
            max_length_added: Optional<Boolean>;
            max_length_changed: Optional<Boolean>;
            max_length_removed: Optional<Boolean>;
            property_name: Optional<Union<[String, Literal<null>]>>;
            property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Boolean>;
            get_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            set_privilege: Optional<Array<Record<{
                name: String;
            }, false>, false>>;
            get_allowed_in_early_execution: Optional<Boolean>;
            set_allowed_in_early_execution: Optional<Boolean>;
            get_disallowed_in_restricted_execution: Optional<Boolean>;
            set_disallowed_in_restricted_execution: Optional<Boolean>;
        }, false>]>, false>, Literal<null>]>>;
        from_module: Optional<Union<[Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>, Literal<null>]>>;
        class_name: Optional<Union<[String, Literal<null>]>>;
        class_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_interface: Optional<Literal<true>>;
        has_member_functions: Optional<Union<[Boolean, Literal<null>]>>;
        show_prior_warning: Optional<Boolean>;
        prior_link: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    enums: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        constants: Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            type: Runtype<MinecraftTypeHelper>;
            is_read_only: Literal<true>;
            is_static: Literal<true>;
            value: Optional<Unknown>;
            property_name: Optional<String>;
            property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            is_member: Optional<Literal<true>>;
            constant_value: Optional<Record<{
                value: Unknown;
            }, false>>;
        }, false>]>, false>;
        from_module: Optional<Union<[Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>, Literal<null>]>>;
        is_enum: Optional<Literal<true>>;
        enum_name: Optional<Union<[String, Literal<null>]>>;
        enum_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        show_prior_warning: Optional<Boolean>;
        prior_link: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
    constants: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        type: Runtype<MinecraftTypeHelper>;
        is_read_only: Literal<true>;
        is_static: Literal<true>;
        value: Optional<Unknown>;
        property_name: Optional<String>;
        property_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        is_member: Optional<Literal<true>>;
        constant_value: Optional<Record<{
            value: Unknown;
        }, false>>;
    }, false>]>, false>, Literal<null>]>>;
    type_aliases: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        has_changes: Optional<Boolean>;
        has_defaults: Optional<Boolean>;
        has_minimum: Optional<Boolean>;
        has_maximum: Optional<Boolean>;
        has_bounds: Optional<Boolean>;
        has_max_length: Optional<Boolean>;
        has_errors: Optional<Boolean>;
        prerelease: Optional<String>;
        is_prerelease: Optional<Boolean>;
        is_deprecated: Optional<Boolean>;
        deprecated_version: Optional<String>;
        has_runtime_conditions: Optional<Boolean>;
        has_closure_privilege_type_comments: Optional<Boolean>;
        has_privilege_comments: Optional<Boolean>;
        ts_has_comments: Optional<Boolean>;
        ts_has_remarks: Optional<Boolean>;
        msdocs_has_comments: Optional<Boolean>;
    }, false>]>, Record<{
        is_script_generated: Optional<Boolean>;
        raw_script_text: Optional<String>;
        raw_tsdoc_text: Optional<String>;
    }, false>, Record<{
        examples: Optional<Array<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            code: Record<{
                text: Array<String, false>;
                escaped_text: Array<String, false>;
            }, false>;
        }, false>]>, false>>;
        deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        closure_privilege_type_name: Optional<String>;
    }, false>]>, Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        alias_type: Optional<Union<[Union<[Literal<MinecraftTypeAliasTypes.TypeMap>, Literal<MinecraftTypeAliasTypes.ScriptGenerated>]>, Literal<null>]>>;
        type: Optional<Union<[Runtype<MinecraftTypeHelper>, Literal<null>]>>;
        mappings: Optional<Union<[Array<Intersect<[Intersect<[Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            has_changes: Optional<Boolean>;
            has_defaults: Optional<Boolean>;
            has_minimum: Optional<Boolean>;
            has_maximum: Optional<Boolean>;
            has_bounds: Optional<Boolean>;
            has_max_length: Optional<Boolean>;
            has_errors: Optional<Boolean>;
            prerelease: Optional<String>;
            is_prerelease: Optional<Boolean>;
            is_deprecated: Optional<Boolean>;
            deprecated_version: Optional<String>;
            has_runtime_conditions: Optional<Boolean>;
            has_closure_privilege_type_comments: Optional<Boolean>;
            has_privilege_comments: Optional<Boolean>;
            ts_has_comments: Optional<Boolean>;
            ts_has_remarks: Optional<Boolean>;
            msdocs_has_comments: Optional<Boolean>;
        }, false>]>, Record<{
            is_script_generated: Optional<Boolean>;
            raw_script_text: Optional<String>;
            raw_tsdoc_text: Optional<String>;
        }, false>, Record<{
            examples: Optional<Array<Intersect<[Record<{
                name: String;
                bookmark_name: Optional<String>;
                filepath_name: Optional<String>;
                variable_name: Optional<String>;
            }, false>, Record<{
                code: Record<{
                    text: Array<String, false>;
                    escaped_text: Array<String, false>;
                }, false>;
            }, false>]>, false>>;
            deprecated_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            throws_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
            closure_privilege_type_name: Optional<String>;
        }, false>]>, Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            value: String;
        }, false>]>, false>, Literal<null>]>>;
        from_module: Optional<Union<[Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>, Literal<null>]>>;
        alias_name: Optional<Union<[String, Literal<null>]>>;
        is_type_map: Optional<Union<[Boolean, Literal<null>]>>;
        alias_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
        show_prior_warning: Optional<Boolean>;
        prior_link: Optional<String>;
    }, false>]>, false>, Literal<null>]>>;
}, false>, Record<{
    module_type: Literal<"script">;
    uuid: String;
    parentModule: Optional<Union<[Union<[String, Record<{
        name: String;
        uuid: Optional<String>;
        version: Optional<String>;
    }, false>]>, Literal<null>]>>;
    marked_up_parent_module: Optional<Record<{
        name: String;
        uuid: String;
        version: String;
    }, false>>;
    dependencies: Optional<Union<[Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        uuid: Optional<String>;
        versions: Array<Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, false>;
        types_only: Optional<Boolean>;
        from_module: Optional<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>>;
        is_latest_major: Optional<Boolean>;
        is_vanilla_data: Optional<Boolean>;
    }, false>]>, false>, Literal<null>]>>;
    peer_dependencies: Optional<Union<[Array<Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        uuid: Optional<String>;
        versions: Array<Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, false>;
        types_only: Optional<Boolean>;
        from_module: Optional<Intersect<[Record<{
            name: String;
            bookmark_name: Optional<String>;
            filepath_name: Optional<String>;
            variable_name: Optional<String>;
        }, false>, Record<{
            version: String;
            version_bookmark_name: Optional<String>;
            version_selector: Optional<String>;
        }, false>, Record<{
            uuid: Optional<String>;
            is_external_module: Optional<Boolean>;
            prior_version: Optional<String>;
            folder_path: Optional<String>;
        }, false>]>>;
        is_latest_major: Optional<Boolean>;
        is_vanilla_data: Optional<Boolean>;
    }, false>]>, false>, Literal<null>]>>;
}, false>, Record<{
    version_is_prerelease: Optional<Boolean>;
    module_prerelease_tag: Optional<Union<[Literal<"alpha">, Literal<"beta">, Literal<"internal">, Literal<"preview">, Literal<"rc">]>>;
    from_module: Optional<Union<[Intersect<[Record<{
        name: String;
        bookmark_name: Optional<String>;
        filepath_name: Optional<String>;
        variable_name: Optional<String>;
    }, false>, Record<{
        version: String;
        version_bookmark_name: Optional<String>;
        version_selector: Optional<String>;
    }, false>, Record<{
        uuid: Optional<String>;
        is_external_module: Optional<Boolean>;
        prior_version: Optional<String>;
        folder_path: Optional<String>;
    }, false>]>, Literal<null>]>>;
    bookmark_name: Optional<Union<[String, Literal<null>]>>;
    available_module_versions: Optional<Union<[Array<String, false>, Literal<null>]>>;
    previous_module_version_chunks: Optional<Array<Record<{
        versions: Union<[Array<String, false>, Literal<null>]>;
        prior_version_link: String;
    }, false>, false>>;
    manifest_example_version_md: Optional<Union<[String, Literal<null>]>>;
    manifest_example_version_ts: Optional<Union<[String, Literal<null>]>>;
    module_description: Optional<Union<[Array<String, false>, Literal<null>]>>;
    md_toc_name: Optional<Union<[String, Literal<null>]>>;
    display_changelog_in_toc: Optional<Boolean>;
    is_latest_module: Optional<Boolean>;
    is_latest_major: Optional<Boolean>;
    show_prior_warning: Optional<Boolean>;
    prior_link: Optional<String>;
    major_version: Optional<Number>;
}, false>]>;
export type MinecraftScriptModule = Static<typeof MinecraftScriptModuleRecord>;
export declare function isScriptModule(module: IMinecraftModule): module is MinecraftScriptModule;
export {};
