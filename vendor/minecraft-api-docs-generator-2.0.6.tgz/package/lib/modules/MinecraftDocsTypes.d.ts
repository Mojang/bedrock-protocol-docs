import { Array, Boolean, Dictionary, Intersect, Number, Optional, Record, Static, String, Union } from 'runtypes';
export declare const CommonDocsDescriptionValidator: Record<{
    description: Optional<Union<[Array<String, false>, String]>>;
}, false>;
export type CommonDocsDescriptionData = Static<typeof CommonDocsDescriptionValidator>;
export declare const ScriptNestedCommonDocsValidator: Intersect<[Record<{
    description: Optional<Union<[Array<String, false>, String]>>;
}, false>, Record<{
    deprecated: Optional<Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>>;
    throws: Optional<Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>>;
}, false>]>;
export type ScriptNestedCommonDocsData = Static<typeof ScriptNestedCommonDocsValidator>;
export declare const ScriptCommonDocsValidator: Record<{
    default: Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>;
    beta: Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    alpha: Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    internal: Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '1': Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '2': Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '3': Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '4': Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '5': Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '6': Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '7': Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '8': Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '9': Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '10': Optional<Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
}, false>;
export type ScriptCommonDocsData = Static<typeof ScriptCommonDocsValidator>;
export declare const ScriptNestedFunctionDocsValidator: Intersect<[Intersect<[Record<{
    description: Optional<Union<[Array<String, false>, String]>>;
}, false>, Record<{
    deprecated: Optional<Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>>;
    throws: Optional<Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>>;
}, false>]>, Record<{
    arguments: Optional<Dictionary<Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
        valid_values: Optional<Array<Union<[String, Number]>, false>>;
    }, false>, string>>;
    returns: Optional<Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>>;
}, false>]>;
export type ScriptNestedFunctionDocsData = Static<typeof ScriptNestedFunctionDocsValidator>;
export declare const ScriptFunctionDocsValidator: Record<{
    default: Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>;
    beta: Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    alpha: Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    internal: Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '1': Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '2': Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '3': Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '4': Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '5': Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '6': Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '7': Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '8': Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '9': Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
    '10': Optional<Intersect<[Intersect<[Record<{
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, Record<{
        deprecated: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
        throws: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>, Record<{
        arguments: Optional<Dictionary<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
            valid_values: Optional<Array<Union<[String, Number]>, false>>;
        }, false>, string>>;
        returns: Optional<Record<{
            description: Optional<Union<[Array<String, false>, String]>>;
        }, false>>;
    }, false>]>>;
}, false>;
export type ScriptFunctionDocsData = Static<typeof ScriptFunctionDocsValidator>;
export declare const CommandDocsValidator: Intersect<[Record<{
    description: Optional<Union<[Array<String, false>, String]>>;
}, false>, Record<{
    arguments: Optional<Array<Record<{
        name: String;
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, false>>;
    overloads: Optional<Array<Record<{
        id: Number;
        description: Optional<Union<[Array<String, false>, String]>>;
        header: Optional<String>;
    }, false>, false>>;
}, false>]>;
export type CommandDocsData = Static<typeof CommandDocsValidator>;
export declare const CommandEnumDocsValidator: Intersect<[Record<{
    description: Optional<Union<[Array<String, false>, String]>>;
}, false>, Record<{
    values: Optional<Array<Record<{
        name: String;
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, false>>;
}, false>]>;
export type CommandEnumDocsData = Static<typeof CommandEnumDocsValidator>;
export declare const BlockDocsValidator: Intersect<[Record<{
    description: Optional<Union<[Array<String, false>, String]>>;
}, false>, Record<{
    properties: Optional<Array<Record<{
        name: String;
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, false>>;
}, false>]>;
export type BlockDocsData = Static<typeof BlockDocsValidator>;
export declare const BlockPropertyDocsValidator: Intersect<[Record<{
    description: Optional<Union<[Array<String, false>, String]>>;
}, false>, Record<{
    values: Optional<Array<Record<{
        name: Union<[String, Number, Boolean]>;
        description: Optional<Union<[Array<String, false>, String]>>;
    }, false>, false>>;
    int_value_display_as_range: Optional<Boolean>;
}, false>]>;
export type BlockPropertyDocsData = Static<typeof BlockPropertyDocsValidator>;
