import { Array, Boolean, Intersect, Literal, Optional, Record, Static, String, Union } from 'runtypes';
import { IMinecraftModule, RuntimeDataModule } from './IMinecraftModule';
import { MinecraftEngineDataModule } from './MinecraftEngineDataModules';
export declare const afterEventsOrderModuleName = "engine-after_events_ordering";
export declare function getAfterEventsOrderingModuleFrom(engineModuleArray: RuntimeDataModule<MinecraftEngineDataModule>[]): {
    name: string;
    minecraft_version: string;
    module_type: "script" | "commands" | "after_events_ordering" | "vanilla_data" | "molang";
    module_name?: string;
} & {
    module_type: "after_events_ordering";
    after_events_order_by_version: ({
        name: string;
    } & {
        version: string;
        event_order: {
            name: string;
        }[];
        version_is_prerelease?: boolean;
        module_prerelease_tag?: "alpha" | "beta" | "internal" | "preview" | "rc";
    })[];
};
export declare const MinecraftAfterEventOrderRecord: Record<{
    name: String;
}, false>;
export type MinecraftEventOrder = Static<typeof MinecraftAfterEventOrderRecord>;
export declare const MinecraftAfterEventsOrderByVersionRecord: Intersect<[Record<{
    name: String;
}, false>, Record<{
    version_is_prerelease: Optional<Boolean>;
    module_prerelease_tag: Optional<Union<[Literal<"alpha">, Literal<"beta">, Literal<"internal">, Literal<"preview">, Literal<"rc">]>>;
    version: String;
    event_order: Array<Record<{
        name: String;
    }, false>, false>;
}, false>]>;
export type MinecraftAfterEventsOrderByVersion = Static<typeof MinecraftAfterEventsOrderByVersionRecord>;
export declare const MinecraftAfterEventsOrderModuleRecord: Intersect<[Record<{
    name: String;
    minecraft_version: String;
    module_type: Union<[Literal<"script">, Literal<"commands">, Literal<"after_events_ordering">, Literal<"vanilla_data">, Literal<"molang">]>;
    module_name: Optional<String>;
}, false>, Record<{
    module_type: Literal<"after_events_ordering">;
    after_events_order_by_version: Array<Intersect<[Record<{
        name: String;
    }, false>, Record<{
        version_is_prerelease: Optional<Boolean>;
        module_prerelease_tag: Optional<Union<[Literal<"alpha">, Literal<"beta">, Literal<"internal">, Literal<"preview">, Literal<"rc">]>>;
        version: String;
        event_order: Array<Record<{
            name: String;
        }, false>, false>;
    }, false>]>, false>;
}, false>]>;
export type MinecraftAfterEventsOrderModule = Static<typeof MinecraftAfterEventsOrderModuleRecord>;
export declare function isAfterEventsOrderModule(module: IMinecraftModule): module is MinecraftAfterEventsOrderModule;
