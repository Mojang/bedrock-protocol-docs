import { Array, Boolean, Intersect, Literal, Number, Optional, Record, Static, String } from 'runtypes';
import { IMinecraftModule } from './IMinecraftModule';
export declare const MinecraftCommandEnumValueRecord: Record<{
    value: String;
    has_comments: Optional<Boolean>;
    value_description: Optional<Array<String, false>>;
}, false>;
export type MinecraftCommandEnumValue = Static<typeof MinecraftCommandEnumValueRecord>;
export declare const MinecraftCommandEnumRecord: Record<{
    name: String;
    values: Array<Record<{
        value: String;
        has_comments: Optional<Boolean>;
        value_description: Optional<Array<String, false>>;
    }, false>, false>;
    enum_name: Optional<String>;
    command_references: Optional<Array<Record<{
        command_name: String;
        command_index: Number;
    }, false>, false>>;
    has_comments: Optional<Boolean>;
    enum_description: Optional<Array<String, false>>;
}, false>;
export type MinecraftCommandEnum = Static<typeof MinecraftCommandEnumRecord>;
export declare const MinecraftCommandAliasRecord: Record<{
    name: String;
    alias_name: Optional<String>;
}, false>;
export type MinecraftCommandAlias = Static<typeof MinecraftCommandAliasRecord>;
export declare const MinecraftCommandArgumentTypeRecord: Record<{
    name: String;
    type_name: Optional<String>;
    keyword_name: Optional<String>;
    is_enum: Optional<Boolean>;
    is_keyword: Optional<Boolean>;
    has_link: Optional<Boolean>;
    syntax: Optional<String>;
    has_comments: Optional<Boolean>;
    type_description: Optional<Array<String, false>>;
}, false>;
export type MinecraftCommandArgumentType = Static<typeof MinecraftCommandArgumentTypeRecord>;
export declare const MinecraftCommandArgumentRecord: Record<{
    name: String;
    is_optional: Boolean;
    type: Record<{
        name: String;
        type_name: Optional<String>;
        keyword_name: Optional<String>;
        is_enum: Optional<Boolean>;
        is_keyword: Optional<Boolean>;
        has_link: Optional<Boolean>;
        syntax: Optional<String>;
        has_comments: Optional<Boolean>;
        type_description: Optional<Array<String, false>>;
    }, false>;
    param_name: Optional<String>;
    directory_name: Optional<String>;
    has_comments: Optional<Boolean>;
    argument_description: Optional<Array<String, false>>;
}, false>;
export type MinecraftCommandArgument = Static<typeof MinecraftCommandArgumentRecord>;
export declare const MinecraftCommandOverloadRecord: Record<{
    name: String;
    params: Array<Record<{
        name: String;
        is_optional: Boolean;
        type: Record<{
            name: String;
            type_name: Optional<String>;
            keyword_name: Optional<String>;
            is_enum: Optional<Boolean>;
            is_keyword: Optional<Boolean>;
            has_link: Optional<Boolean>;
            syntax: Optional<String>;
            has_comments: Optional<Boolean>;
            type_description: Optional<Array<String, false>>;
        }, false>;
        param_name: Optional<String>;
        directory_name: Optional<String>;
        has_comments: Optional<Boolean>;
        argument_description: Optional<Array<String, false>>;
    }, false>, false>;
    has_comments: Optional<Boolean>;
    overload_description: Optional<Array<String, false>>;
    overload_header: Optional<String>;
}, false>;
export type MinecraftCommandOverload = Static<typeof MinecraftCommandOverloadRecord>;
export declare const MinecraftCommandRecord: Record<{
    name: String;
    permission_level: Number;
    requires_cheats: Boolean;
    description: Optional<String>;
    aliases: Optional<Array<Record<{
        name: String;
        alias_name: Optional<String>;
    }, false>, false>>;
    overloads: Optional<Array<Record<{
        name: String;
        params: Array<Record<{
            name: String;
            is_optional: Boolean;
            type: Record<{
                name: String;
                type_name: Optional<String>;
                keyword_name: Optional<String>;
                is_enum: Optional<Boolean>;
                is_keyword: Optional<Boolean>;
                has_link: Optional<Boolean>;
                syntax: Optional<String>;
                has_comments: Optional<Boolean>;
                type_description: Optional<Array<String, false>>;
            }, false>;
            param_name: Optional<String>;
            directory_name: Optional<String>;
            has_comments: Optional<Boolean>;
            argument_description: Optional<Array<String, false>>;
        }, false>, false>;
        has_comments: Optional<Boolean>;
        overload_description: Optional<Array<String, false>>;
        overload_header: Optional<String>;
    }, false>, false>>;
    command_name: Optional<String>;
    permission_level_name: Optional<String>;
    arguments: Optional<Array<Record<{
        name: String;
        is_optional: Boolean;
        type: Record<{
            name: String;
            type_name: Optional<String>;
            keyword_name: Optional<String>;
            is_enum: Optional<Boolean>;
            is_keyword: Optional<Boolean>;
            has_link: Optional<Boolean>;
            syntax: Optional<String>;
            has_comments: Optional<Boolean>;
            type_description: Optional<Array<String, false>>;
        }, false>;
        param_name: Optional<String>;
        directory_name: Optional<String>;
        has_comments: Optional<Boolean>;
        argument_description: Optional<Array<String, false>>;
    }, false>, false>>;
    command_enums: Optional<Array<Record<{
        name: String;
        values: Array<Record<{
            value: String;
            has_comments: Optional<Boolean>;
            value_description: Optional<Array<String, false>>;
        }, false>, false>;
        enum_name: Optional<String>;
        command_references: Optional<Array<Record<{
            command_name: String;
            command_index: Number;
        }, false>, false>>;
        has_comments: Optional<Boolean>;
        enum_description: Optional<Array<String, false>>;
    }, false>, false>>;
    has_comments: Optional<Boolean>;
    command_description: Optional<Array<String, false>>;
}, false>;
export type MinecraftCommand = Static<typeof MinecraftCommandRecord>;
export declare const MinecraftCommandModuleRecord: Intersect<[Record<{
    name: String;
    minecraft_version: String;
    module_type: import("runtypes").Union<[Literal<"script">, Literal<"commands">, Literal<"after_events_ordering">, Literal<"vanilla_data">, Literal<"molang">]>;
    module_name: Optional<String>;
}, false>, Record<{
    module_type: Literal<"commands">;
    commands: Optional<Array<Record<{
        name: String;
        permission_level: Number;
        requires_cheats: Boolean;
        description: Optional<String>;
        aliases: Optional<Array<Record<{
            name: String;
            alias_name: Optional<String>;
        }, false>, false>>;
        overloads: Optional<Array<Record<{
            name: String;
            params: Array<Record<{
                name: String;
                is_optional: Boolean;
                type: Record<{
                    name: String;
                    type_name: Optional<String>;
                    keyword_name: Optional<String>;
                    is_enum: Optional<Boolean>;
                    is_keyword: Optional<Boolean>;
                    has_link: Optional<Boolean>;
                    syntax: Optional<String>;
                    has_comments: Optional<Boolean>;
                    type_description: Optional<Array<String, false>>;
                }, false>;
                param_name: Optional<String>;
                directory_name: Optional<String>;
                has_comments: Optional<Boolean>;
                argument_description: Optional<Array<String, false>>;
            }, false>, false>;
            has_comments: Optional<Boolean>;
            overload_description: Optional<Array<String, false>>;
            overload_header: Optional<String>;
        }, false>, false>>;
        command_name: Optional<String>;
        permission_level_name: Optional<String>;
        arguments: Optional<Array<Record<{
            name: String;
            is_optional: Boolean;
            type: Record<{
                name: String;
                type_name: Optional<String>;
                keyword_name: Optional<String>;
                is_enum: Optional<Boolean>;
                is_keyword: Optional<Boolean>;
                has_link: Optional<Boolean>;
                syntax: Optional<String>;
                has_comments: Optional<Boolean>;
                type_description: Optional<Array<String, false>>;
            }, false>;
            param_name: Optional<String>;
            directory_name: Optional<String>;
            has_comments: Optional<Boolean>;
            argument_description: Optional<Array<String, false>>;
        }, false>, false>>;
        command_enums: Optional<Array<Record<{
            name: String;
            values: Array<Record<{
                value: String;
                has_comments: Optional<Boolean>;
                value_description: Optional<Array<String, false>>;
            }, false>, false>;
            enum_name: Optional<String>;
            command_references: Optional<Array<Record<{
                command_name: String;
                command_index: Number;
            }, false>, false>>;
            has_comments: Optional<Boolean>;
            enum_description: Optional<Array<String, false>>;
        }, false>, false>>;
        has_comments: Optional<Boolean>;
        command_description: Optional<Array<String, false>>;
    }, false>, false>>;
    command_enums: Optional<Array<Record<{
        name: String;
        values: Array<Record<{
            value: String;
            has_comments: Optional<Boolean>;
            value_description: Optional<Array<String, false>>;
        }, false>, false>;
        enum_name: Optional<String>;
        command_references: Optional<Array<Record<{
            command_name: String;
            command_index: Number;
        }, false>, false>>;
        has_comments: Optional<Boolean>;
        enum_description: Optional<Array<String, false>>;
    }, false>, false>>;
    command_types: Optional<Array<Record<{
        name: String;
        type_name: Optional<String>;
        keyword_name: Optional<String>;
        is_enum: Optional<Boolean>;
        is_keyword: Optional<Boolean>;
        has_link: Optional<Boolean>;
        syntax: Optional<String>;
        has_comments: Optional<Boolean>;
        type_description: Optional<Array<String, false>>;
    }, false>, false>>;
}, false>]>;
export type MinecraftCommandModule = Static<typeof MinecraftCommandModuleRecord>;
export declare function isCommandModule(module: IMinecraftModule): module is MinecraftCommandModule;
