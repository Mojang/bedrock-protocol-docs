import { Array, Boolean, Intersect, Literal, Number, Optional, Record, Static, String, Union } from 'runtypes';
export declare const MinecraftBlockRecord: Intersect<[Record<{
    name: String;
}, false>, Record<{
    namespace: Optional<String>;
    no_namespace_name: Optional<String>;
    standardized_name: Optional<String>;
}, false>, Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    properties: Array<Intersect<[Record<{
        name: String;
    }, false>, Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        property_description: Optional<Array<String, false>>;
    }, false>]>, false>;
    namespace: Optional<String>;
    block_name: Optional<String>;
    block_description: Optional<Array<String, false>>;
    state_union: Optional<String>;
}, false>]>;
export type MinecraftBlock = Static<typeof MinecraftBlockRecord>;
export declare const MinecraftBlockPropertyValueRecord: Intersect<[Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    value: Union<[Number, String, Boolean]>;
    value_description: Optional<Array<String, false>>;
}, false>]>;
export type MinecraftBlockPropertyValue = Static<typeof MinecraftBlockPropertyValueRecord>;
export declare const MinecraftBlockPropertyRecord: Intersect<[Record<{
    name: String;
}, false>, Record<{
    has_comments: Optional<Boolean>;
}, false>, Record<{
    type: String;
    values: Array<Intersect<[Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        value: Union<[Number, String, Boolean]>;
        value_description: Optional<Array<String, false>>;
    }, false>]>, false>;
    min_value: Optional<Number>;
    max_value: Optional<Number>;
    property_name: Optional<String>;
    property_description: Optional<Array<String, false>>;
    property_type: Optional<Union<[Literal<"number">, Union<[Literal<"string">, Literal<"boolean">]>]>>;
    int_value_display_as_range: Optional<Boolean>;
}, false>]>;
export type MinecraftBlockProperty = Static<typeof MinecraftBlockPropertyRecord>;
export declare const MinecraftBlockModuleRecord: Intersect<[Record<{
    module_type: Literal<"vanilla_data">;
    block_properties: Array<Intersect<[Record<{
        name: String;
    }, false>, Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        type: String;
        values: Array<Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            value: Union<[Number, String, Boolean]>;
            value_description: Optional<Array<String, false>>;
        }, false>]>, false>;
        min_value: Optional<Number>;
        max_value: Optional<Number>;
        property_name: Optional<String>;
        property_description: Optional<Array<String, false>>;
        property_type: Optional<Union<[Literal<"number">, Union<[Literal<"string">, Literal<"boolean">]>]>>;
        int_value_display_as_range: Optional<Boolean>;
    }, false>]>, false>;
    data_properties: Optional<Array<Intersect<[Record<{
        name: String;
    }, false>, Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        type: String;
        values: Array<Intersect<[Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            value: Union<[Number, String, Boolean]>;
            value_description: Optional<Array<String, false>>;
        }, false>]>, false>;
        min_value: Optional<Number>;
        max_value: Optional<Number>;
        property_name: Optional<String>;
        property_description: Optional<Array<String, false>>;
        property_type: Optional<Union<[Literal<"number">, Union<[Literal<"string">, Literal<"boolean">]>]>>;
        int_value_display_as_range: Optional<Boolean>;
    }, false>]>, false>>;
}, false>, Intersect<[Intersect<[Record<{
    data_items: Array<Intersect<[Intersect<[Record<{
        name: String;
    }, false>, Record<{
        namespace: Optional<String>;
        no_namespace_name: Optional<String>;
        standardized_name: Optional<String>;
    }, false>]>, Record<{
        properties: Optional<Array<Record<{
            name: String;
        }, false>, false>>;
        state_union: Optional<String>;
        value: Optional<String>;
    }, false>]>, false>;
    vanilla_data_type: Optional<String>;
    module_type: Literal<"vanilla_data">;
    display_type: Optional<String>;
    display_name: Optional<String>;
    has_properties: Optional<Boolean>;
}, false>, Record<{
    name: String;
    minecraft_version: String;
    module_type: Union<[Literal<"script">, Literal<"commands">, Literal<"after_events_ordering">, Literal<"vanilla_data">, Literal<"molang">]>;
    module_name: Optional<String>;
}, false>]>, Record<{
    data_items: Array<Intersect<[Record<{
        name: String;
    }, false>, Record<{
        namespace: Optional<String>;
        no_namespace_name: Optional<String>;
        standardized_name: Optional<String>;
    }, false>, Record<{
        has_comments: Optional<Boolean>;
    }, false>, Record<{
        properties: Array<Intersect<[Record<{
            name: String;
        }, false>, Record<{
            has_comments: Optional<Boolean>;
        }, false>, Record<{
            property_description: Optional<Array<String, false>>;
        }, false>]>, false>;
        namespace: Optional<String>;
        block_name: Optional<String>;
        block_description: Optional<Array<String, false>>;
        state_union: Optional<String>;
    }, false>]>, false>;
    vanilla_data_type: Optional<Literal<string>>;
}, false>]>]>;
export type MinecraftBlockModule = Static<typeof MinecraftBlockModuleRecord>;
