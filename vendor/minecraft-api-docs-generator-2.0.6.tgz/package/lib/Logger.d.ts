import * as rt from 'runtypes';
export declare enum LogLevel {
    Debug = 0,
    Info = 1,
    Warn = 2,
    Error = 3
}
declare const LogMessageRecord: rt.Union<[rt.Literal<"undocumentedApis">, rt.Literal<"unusedDocumentation">, rt.Literal<"unresolvedDependencies">, rt.Literal<"unresolvedTypes">]>;
export type LogMessage = rt.Static<typeof LogMessageRecord>;
export declare const LogOptionsRecord: rt.Record<{
    level: rt.Optional<rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>>;
    allMessages: rt.Optional<rt.Union<[rt.Boolean, rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>]>>;
    undocumentedApis: rt.Optional<rt.Union<[rt.Boolean, rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>]>>;
    unusedDocumentation: rt.Optional<rt.Union<[rt.Boolean, rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>]>>;
    unresolvedDependencies: rt.Optional<rt.Union<[rt.Boolean, rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>]>>;
    unresolvedTypes: rt.Optional<rt.Union<[rt.Boolean, rt.Union<[rt.Literal<"debug">, rt.Literal<"info">, rt.Literal<"warn">, rt.Literal<"error">]>]>>;
}, false>;
export type LogOptions = rt.Static<typeof LogOptionsRecord>;
/**
 * `printOption()` uses the log levels defined here to determine the level a message should be printed at.
 *
 * Note: true is equivalent to 'warn', undefined defaults to 'debug', false does not print.
 */
export declare const DefaultLogOptions: LogOptions;
export declare function print(text: string, level?: LogLevel): void;
/**
 * Prints according to the specified log level setting for 'messageId', or:
 *
 * If 'messageId' is set to true, will print to 'warn' log level.
 * If 'messageId' is undefined, will print to 'debug' log level.
 * If 'messageId' is set to false, will not print.
 */
export declare function printOption(text: string, messageId: LogMessage): void;
export declare function debug(text: string): void;
export declare function info(text: string): void;
export declare function warn(text: string): void;
export declare function error(text: string): void;
export declare function assert(assertion: boolean, text: string): void;
export declare function setLogOptions(options: LogOptions): void;
export declare function getLogOptions(): LogOptions;
export declare function getLogLevel(): LogLevel;
export interface ILogger {
    options: LogOptions;
    level: LogLevel;
    debug(text: string): void;
    info(text: string): void;
    warn(text: string): void;
    error(text: string): void;
    assert(text: string): void;
    setLogOptions(options: LogOptions): void;
}
export declare class TerminalLogger implements ILogger {
    options: LogOptions;
    level: LogLevel;
    debug(text: string): void;
    info(text: string): void;
    warn(text: string): void;
    error(text: string): void;
    assert(text: string): void;
    setLogOptions(options: LogOptions): void;
}
export declare class LoggerInstance {
    static instance: ILogger;
}
export {};
