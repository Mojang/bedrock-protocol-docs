export declare class FileLoader {
    private fileCache;
    private filePathIsCached;
    private rootFilePath;
    private supportedExtensions;
    constructor(rootFilePath: string, extensions?: string[]);
    loaded(): boolean;
    canLoadFile(filePath: string): boolean;
    readFile(filePath: string): Buffer;
    readFileAsString(filePath: string): string;
    joinToRoot(directory: string): string;
    logUnusedFiles(): void;
}
