import { FilterGroup } from './Filters';
export declare const TypeScriptFilters: FilterGroup;
