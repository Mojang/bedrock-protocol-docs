import { FilterGroup } from './Filters';
export declare const CommonFilters: FilterGroup;
