import { FilterGroup } from './Filters';
export declare const MarkdownFilters: FilterGroup;
