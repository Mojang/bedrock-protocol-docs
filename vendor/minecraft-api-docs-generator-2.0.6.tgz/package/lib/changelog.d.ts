import { ChangelogStrategy } from './ChangelogStrategy';
import { MinecraftRelease } from './MinecraftRelease';
export declare class ChangelogGenerator {
    constructor(_config: ChangelogStrategy);
    config: ChangelogStrategy;
    private getChangelogForVersion;
    private compareArray;
    private generate;
    private generateModuleChangeLog;
    generateChangelogs(releases: MinecraftRelease[]): void;
}
