import { IMinecraftModule, RuntimeDataModule } from './modules/IMinecraftModule';
import { MinecraftBlockModule } from './modules/MinecraftBlockModule';
import { MinecraftCommandModule } from './modules/MinecraftCommandModule';
import { MinecraftEngineDataModule } from './modules/MinecraftEngineDataModules';
import { MinecraftMolangModule } from './modules/MinecraftMolangModule';
import { MinecraftJsonSchemaMap, MinecraftProtocolSchemaMap } from './modules/MinecraftSchemaObject';
import { MinecraftScriptModule } from './modules/MinecraftScriptModule';
import { MinecraftVanillaDataModule } from './modules/MinecraftVanillaDataModules';
export declare enum GetLatestScriptModulesOptions {
    OnlyStable = 0,
    OnlyPrerelease = 1,
    StableAndPrerelease = 2
}
export declare function getLatestScriptModules(modules: MinecraftScriptModule[], options?: GetLatestScriptModulesOptions): MinecraftScriptModule[];
export declare class MinecraftRelease {
    minecraft_version: string;
    script_modules: RuntimeDataModule<MinecraftScriptModule>[];
    command_modules: RuntimeDataModule<MinecraftCommandModule>[];
    block_modules: RuntimeDataModule<MinecraftBlockModule>[];
    vanilla_data_modules: RuntimeDataModule<MinecraftVanillaDataModule>[];
    engine_data_modules: RuntimeDataModule<MinecraftEngineDataModule>[];
    molang_modules: RuntimeDataModule<MinecraftMolangModule>[];
    json_schemas: MinecraftJsonSchemaMap;
    protocol_schemas: MinecraftProtocolSchemaMap;
    constructor(minecraft_version: string);
    copy(): MinecraftRelease;
    getAllModules(): IMinecraftModule[];
    /**
     * Gets only the latest version of each script module. This prioritizes pre-release modules if they exist.
     *
     * @param options Provides options to only get the latest stable versions, or the latest pre-release versions, of each module.
     */
    getLatestScriptModules(options?: GetLatestScriptModulesOptions): MinecraftScriptModule[];
    /**
     * Gets the latest version of each major release of each script module. This prioritizes pre-release modules if they exist.
     *
     * @param options Provides options to only get the latest stable versions, or the latest pre-release versions, of each major release.
     */
    getLatestScriptModulesByMajorVersion(options?: GetLatestScriptModulesOptions): MinecraftScriptModule[];
}
