import { ChangelogStrategy } from './ChangelogStrategy';
import { GenerateOptions, IncludeModulesMode } from './Config';
import { FileLoader } from './FileLoader';
import { MarkupGenerator, MarkupGeneratorOptions } from './plugins';
export declare class GeneratorContext {
    private readonly config;
    readonly changelogStrategy: ChangelogStrategy;
    readonly inputDirectory: string;
    readonly rootOutputDirectory: string;
    readonly documentationFileLoader: FileLoader | undefined;
    private readonly generators;
    private readonly templates;
    private constructor();
    static Init(cliOptions: GenerateOptions): Promise<GeneratorContext>;
    get minecraftReleaseVersion(): string | undefined;
    get preexistingModuleReleases(): Record<string, string[]> | undefined;
    get includeModules(): IncludeModulesMode;
    get includeBaseModules(): boolean;
    get skipMerging(): boolean;
    getGenerator(generatorId: string): MarkupGenerator;
    getGeneratorOptions(generatorId: string): MarkupGeneratorOptions;
    getGenerators(): Iterable<MarkupGenerator>;
    getGeneratorIds(): string[];
    hasGenerators(...generatorIds: string[]): boolean;
    getTemplates(...templateIds: string[]): Record<string, FileLoader>;
    hasTemplates(...templateIds: string[]): boolean;
    shutdown(): void;
}
