import { Config } from 'prettier';
export declare const PRETTIER_CONFIGURATION: Config;
