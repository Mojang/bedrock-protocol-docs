import { MinecraftRelease } from './MinecraftRelease';
export type ProtocolTypeCategory = 'array' | 'enum' | 'object' | 'scalar' | 'union' | 'other';
export interface ProtocolVariant {
    index: number;
    target?: string;
    title: string;
    type: string;
}
export interface ProtocolField {
    children?: ProtocolField[];
    description: string;
    enumBinaryValues?: number[];
    enumValues?: string[];
    name: string;
    optional: boolean;
    ordinal?: number;
    serialization: string[];
    target?: string;
    type: string;
    variants?: ProtocolVariant[];
    wireSize: string;
    wireSizeBytes: number;
}
export interface ProtocolUse {
    packetId?: number;
    packetSlug: string;
    packetTitle: string;
    path: string[];
}
export interface ProtocolWireFormat {
    serialization: string[];
    type: string;
}
export interface ProtocolTypeDocument {
    category: ProtocolTypeCategory;
    description: string;
    enumBinaryValues?: number[];
    enumValues: string[];
    fields: ProtocolField[];
    serialization: string[];
    slug: string;
    title: string;
    uses: ProtocolUse[];
    wireFormats: ProtocolWireFormat[];
}
export interface ProtocolPacketDocument {
    description: string;
    details: string;
    fields: ProtocolField[];
    id: number;
    slug: string;
    title: string;
}
export interface ProtocolPrimitiveDocument {
    category: 'Boolean' | 'Floating point' | 'Signed integer' | 'Text' | 'Unsigned integer';
    encoding: string;
    size: string;
    slug: string;
    title: string;
}
export interface ProtocolChangeItem {
    changes: ProtocolChange[];
    slug: string;
    title: string;
}
export interface ProtocolChange {
    addedType?: ProtocolTypeChangeContext;
    changedType?: ProtocolTypeChangeContext;
    fieldAdded?: ProtocolFieldAdded;
    fieldEnumValueAdded?: ProtocolFieldEnumValueChange;
    fieldEnumValueOrdinalChanged?: ProtocolFieldEnumValueOrdinalChange;
    fieldEnumValueRemoved?: ProtocolFieldEnumValueChange;
    fieldOptionalChanged?: ProtocolFieldOptionalChange;
    fieldOrdinalChanged?: ProtocolFieldOrdinalChange;
    fieldRemoved?: ProtocolFieldRemoved;
    fieldSerializationOptionAdded?: ProtocolFieldSerializationOptionChange;
    fieldSerializationOptionRemoved?: ProtocolFieldSerializationOptionChange;
    fieldTypeChanged?: ProtocolFieldTypeChange;
    fieldVariantsChanged?: ProtocolFieldVariantsChange;
    removedType?: ProtocolTypeChangeContext;
    typeAdded?: ProtocolTypeAddedOrRemoved;
    typeCategoryChanged?: ProtocolTypeCategoryChange;
    typeEnumValueAdded?: ProtocolTypeEnumValueChange;
    typeEnumValueOrdinalChanged?: ProtocolTypeEnumValueOrdinalChange;
    typeEnumValueRemoved?: ProtocolTypeEnumValueChange;
    typeRemoved?: ProtocolTypeAddedOrRemoved;
    typeSerializationOptionAdded?: ProtocolTypeSerializationOptionChange;
    typeSerializationOptionRemoved?: ProtocolTypeSerializationOptionChange;
}
export interface ProtocolFieldChangeContext {
    path: string;
    target?: string;
}
export interface ProtocolFieldAdded extends ProtocolFieldChangeContext {
    type: string;
}
export interface ProtocolFieldEnumValueChange extends ProtocolFieldChangeContext {
    ordinal: number;
    value: string;
}
export interface ProtocolFieldEnumValueOrdinalChange extends ProtocolTypeEnumValueOrdinalChange, ProtocolFieldChangeContext {
}
export interface ProtocolFieldOrdinalChange extends ProtocolFieldChangeContext {
    ordinal?: number;
    ordinalAssigned: boolean;
    previousOrdinal?: number;
    previousOrdinalAssigned: boolean;
}
export interface ProtocolFieldRemoved extends ProtocolFieldChangeContext {
    type: string;
}
export interface ProtocolFieldOptionalChange extends ProtocolFieldChangeContext {
    optional: boolean;
}
export interface ProtocolFieldSerializationOptionChange extends ProtocolFieldChangeContext {
    option: string;
}
export interface ProtocolFieldTypeChange extends ProtocolFieldChangeContext {
    previousTarget?: string;
    previousType: string;
    type: string;
}
export type ProtocolFieldVariantsChange = ProtocolFieldChangeContext;
export interface ProtocolTypeAddedOrRemoved {
    category: ProtocolTypeCategory;
}
export interface ProtocolTypeCategoryChange {
    category: ProtocolTypeCategory;
    previousCategory: ProtocolTypeCategory;
}
export interface ProtocolTypeChangeContext {
    slug?: string;
    title: string;
}
export interface ProtocolTypeEnumValueChange {
    ordinal: number;
    value: string;
}
export interface ProtocolTypeEnumValueOrdinalChange {
    ordinal: number;
    previousOrdinal: number;
    value: string;
}
export interface ProtocolTypeSerializationOptionChange {
    option: string;
}
export interface ProtocolPacketChangeItem extends ProtocolChangeItem {
    packetId: number;
    previousPacketId?: number;
}
export interface ProtocolChangeSet<T extends ProtocolChangeItem = ProtocolChangeItem> {
    added: T[];
    changed: T[];
    removed: T[];
}
export interface ProtocolChangelogRelease {
    minecraftVersion: string;
    packets: ProtocolChangeSet<ProtocolPacketChangeItem>;
    previousProtocolVersion: string;
    previousVersion: string;
    protocolVersion: string;
    releaseDate: string;
    totalChanges: number;
    versionDidChange: boolean;
    version: string;
}
export interface ProtocolReleaseMetadata {
    minecraftVersion: string;
    packets: ProtocolPacketDocument[];
    primitives: ProtocolPrimitiveDocument[];
    protocolVersion: string;
    types: ProtocolTypeDocument[];
}
export interface ProtocolMetadataDocument extends ProtocolReleaseMetadata {
    changelog: ProtocolChangelogRelease[];
}
export interface ProtocolReleaseSnapshot {
    release: MinecraftRelease;
    releaseDate: string;
    version: string;
}
/**
 * Compares normalized protocol release metadata and produces release changelogs.
 * Snapshots must be ordered from newest to oldest.
 */
export declare class ProtocolChangelogGenerator {
    private readonly releaseCount;
    private readonly schemasByKey;
    private readonly schemasByTitle;
    private readonly usedPacketSlugs;
    private readonly usedTypeSlugs;
    constructor(releaseCount?: number);
    private uniqueSlug;
    private packetId;
    private isPacket;
    private registerSchema;
    private registerNestedSchemas;
    private indexSchemas;
    private resolveReference;
    private referencedSchema;
    private underlyingType;
    private wireSize;
    private createFields;
    private packetPayload;
    private packetPayloadSlugs;
    private createPackets;
    private createTypes;
    private addObservedWireFormats;
    private addIncludeHierarchy;
    private createPrimitives;
    generateReleaseMetadata(release: MinecraftRelease): ProtocolReleaseMetadata;
    private compareFields;
    private compareEnumValues;
    private compareFieldSerializationOptions;
    private compareTypeSerializationOptions;
    private comparePackets;
    private compareTypes;
    private addTypeChangesToPackets;
    private sortChangeSet;
    generateChangelogs(releases: Array<MinecraftRelease | ProtocolReleaseSnapshot>): ProtocolChangelogRelease[];
}
