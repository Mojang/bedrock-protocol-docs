import { Filter } from './Filters';
export declare const CommandMarkupFilter: Filter;
